<?php

    // parse includes
    // --------------
 			include("../../include/my_vars.php");
			include("../../include/my_db.php");
			include("../../include/my_functions.php");


    // process, if user pressed 'submit'
    //----------------------------------
        if ( isset($_POST['submit']) ) {
 

            // retrieve details from input
            //----------------------------------
                $user  		= filter_var($_POST['user'], FILTER_SANITIZE_STRING);
                $hive       = filter_var($_POST['hive'], FILTER_SANITIZE_STRING);

                $user_msg  	= filter_var($_POST['user_msg'], FILTER_SANITIZE_STRING);
                $hive_msg  	= filter_var($_POST['hive_msg'], FILTER_SANITIZE_STRING);
            
        
			// if user message
			// ---------------
				if( $user && $user_msg) {

					$query = sprintf("INSERT INTO msg_user ( msg_user_user_id, msg_user_msg, msg_user_date) values(%s, %s, now())",	clean_input( $user ), clean_input( $user_msg ) );
					$result = $db->query($query);
					
				}

			// if hive message
			// ---------------
				if( $hive && $hive_msg) {

					$query = sprintf("SELECT hive_user_user_id FROM hive_user WHERE hive_user_hive_id=%s AND hive_user_status IS NULL ", clean_input($hive) );
					$result = $db->query($query); 

					if ( count($result) > 0 ) {

						foreach( $result as $i ) {
							
							$query = sprintf("INSERT INTO msg_hive ( msg_hive_hive_id, msg_hive_user_id, msg_hive_msg, msg_hive_date) values(%s, %s, %s, now())",	clean_input( $hive ), clean_input($i->hive_user_user_id), clean_input( $hive_msg )	);
							$result = $db->query($query);

							}
						
						}
					
				}


    }

?>


<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>StriveHive</title>

  <!-- Bootstrap core CSS -->
  <link href="../../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="../../css/scrolling-nav.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="index.php">StriveHive : Admin</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="messenger.php">Messenger</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="messenge-hive.php">Hives</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="messenge-user.php">Users</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <header class="bg-primary text-white">
    <div class="container text-center"></div>
  </header>

  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">

        <form action="<?php echo ($_SERVER["PHP_SELF"])?>" method="POST" id="needs-validation" novalidate> 
          
        
            <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group">  
                        <label for="user">User</label>  
                        <input type="text" name="user" class="form-control" aria-describedby="inputGroupPrepend" />  
                    </div>  
                </div>  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group"> 
                        <label for="hive">Hive</label>  
                        <input type="text" name="hive" class="form-control" aria-describedby="inputGroupPrepend" />  
                    </div>  
                </div>  
            </div>  


            <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-6">  
                    <div class="form-group">  
                        <label for="user_msg">User Message</label>  
                        <textarea class="form-control" rows="7" name="user_msg" aria-describedby="inputGroupPrepend"></textarea>  
                    </div>  
                </div>  
 
                <div class="col-sm-6 col-md-6 col-xs-6">  
                     <div class="form-group">  
                        <label for="hive_msg">Hive Message</label>  
                        <textarea class="form-control" rows="7" name="hive_msg" aria-describedby="inputGroupPrepend"></textarea>  
                    </div>  
                </div>  
             </div>  

            <div class="row">  
                <div class="col-sm-12 col-md-12 col-xs-12">  
                    <div class="float-right">  
                         <button class="btn btn-primary rounded-0" type="submit" name='submit' id="submit">Send Message</button>  
                    </div>                            
                </div>  
            </div>  
        </form>  


        </div>
      </div>
    </div>
  </section>


  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; StriveHive 2021</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="../../vendor/jquery/jquery.min.js"></script>
  <script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="../../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="../../js/scrolling-nav.js"></script>

</body>

</html>
