<?php

 			include("../include/my_vars.php");
			include("../include/my_db.php");
			include("../include/my_functions.php");


// retrieve page id
// ----------------
		$exercise = filter_var($_GET['ID1'], FILTER_SANITIZE_STRING);
		$muscle   = filter_var($_GET['ID2'], FILTER_SANITIZE_STRING);

// delete page
// -----------
		if ($exercise && $muscle) {

			$query = sprintf("DELETE FROM exercise_muscle WHERE exercise_muscle_exercise_id=%s AND exercise_muscle_muscle_id=%s ", clean_input( $exercise ), clean_input( $muscle ) );
			$result = $db->query($query);
			
			$location = 'exercise-detail.php?ID=' .$exercise ;
 			header( "Location: $location" );
 			exit;

		}
		else {

			displayError ("Input error. An error had occured while processing your submission. Please retry later.");
			exit;

}
