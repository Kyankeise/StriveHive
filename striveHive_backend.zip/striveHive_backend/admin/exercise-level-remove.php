<?php

 			include("../include/my_vars.php");
			include("../include/my_db.php");
			include("../include/my_functions.php");


// retrieve page id
// ----------------
		$exercise = filter_var($_GET['ID1'], FILTER_SANITIZE_STRING);
		$level   = filter_var($_GET['ID2'], FILTER_SANITIZE_STRING);

// delete page
// -----------
		if ($exercise && $level) {

			$query = sprintf("DELETE FROM exercise_level WHERE exercise_level_exercise_id=%s AND exercise_level_level_id=%s ", clean_input( $exercise ), clean_input( $level ) );
			$result = $db->query($query);
			
			$location = 'exercise-detail.php?ID=' .$exercise ;
 			header( "Location: $location" );
 			exit;

		}
		else {

			displayError ("Input error. An error had occured while processing your submission. Please retry later.");
			exit;

}
