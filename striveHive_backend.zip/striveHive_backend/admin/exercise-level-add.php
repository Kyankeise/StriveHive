<?php

    // parse includes
    // --------------
 			include("../include/my_vars.php");
			include("../include/my_db.php");
			include("../include/my_functions.php");
			include("../include/ex_files.php") ;


// process if submit or cancel button is pressed
// ---------------------------------------------
 	if ( isset($_POST['submit']) || isset($_POST['cancel'])   ) {


				// return if cancelled
				// --------------------
					if (  isset($_POST['cancel'])  ) {

							header( "Location: exercise.php" );
							exit;
					}


				// retrieve input details from form
				// --------------------------------
					$exercise   	= filter_var($_POST['ID1'], FILTER_SANITIZE_STRING);
					$level_ids 	= $_POST['check_list'];


				// validate exercise
				// -----------------
					$query = sprintf("SELECT * FROM exercise WHERE exercise_id=%s LIMIT 1", clean_input( $exercise ) );				
					$result = $db->query($query);

				// return if exercise not found
				// ----------------------------
					if ( count($result) == 0 ) {
						$errmsg = 'Invalid exercise number - Please retry later';
					} 
					
				// validate levels
				// ----------------
					if (count($level_ids) == 0){
						$errmsg = 'Please select level groups to proceed';
					}


				
				// loop and add each mucles in to exercise-level table
				// ----------------------------------------------------
					foreach ( $level_ids as $md ) {

					
						// see if this exercise-level
							$query = sprintf("SELECT * FROM exercise_level WHERE exercise_level_exercise_id=%s AND exercise_level_level_id=%s LIMIT 1", clean_input( $exercise ), clean_input( $md ) );				
							$result = $db->query($query);

							if( count( $result ) == 0 ) {
								
								$query = sprintf("INSERT INTO exercise_level ( exercise_level_exercise_id, exercise_level_level_id ) values(%s, %s)", clean_input( $exercise ), clean_input(  $md ) );
								$result = $db->query($query);

							}
						
						
					}
					
					$location = 'exercise-detail.php?ID=' .$exercise;
					header( "Location: $location" );
					exit;
				
//print_r(compact(array_keys(get_defined_vars()))); exit;

 
	}







	// get the input and clean
	// --------------------       
			if ($_GET['ID1'] != "") {
				$_GET['ID1'] = filter_var($_GET['ID1'], FILTER_SANITIZE_STRING);
			}


	// retrieve input and validate
	// ---------------------------- 	
			$exercise = $_GET['ID1'];
			$query = sprintf("SELECT * FROM exercise WHERE exercise_id=%s LIMIT 1", clean_input( $exercise ) );				
			$result = $db->query($query);

		// return if exercise not found
		// ----------------------------
			if ( count($result) == 0 ) {
                header ("Location: exercise.php");                     
                exit;
			} 
		
		// exercise name
		// -------------		
			$exercise_name = $result[0]->exercise_name ;

		// get existing levels for this exercise
		// --------------------------------------
			$level_array = getlevel( $exercise );

	// setup query & read record
	// -------------------------
			$query  = "SELECT * FROM level ORDER BY level_id";
			$result = $db->query($query);
			$page = '';

			if ( count($result) > 0 ) {

 					foreach( $result as $i ) {
						$key = array_search($i->level_id, array_column($level_array, 'level_id'));	
						if (false !== $key) $chk = 'checked'; else $chk = '';
						
						$page .= '<div class="form-check"><input class="form-check-input" name="check_list[]" type="checkbox" value="' . $i->level_id .'"' .$chk   .'><label class="form-check-label">' .$i->level_name	.'</label></div>';
					}

			}
//print_r(compact(array_keys(get_defined_vars()))); exit;

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>StriveHive</title>

  <!-- Bootstrap core CSS -->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="../css/scrolling-nav.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="index.php">StriveHive : Admin</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="search.php">Search</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="exercise.php">Exercise</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="muscle.php">Muscle</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="category.php">Category</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="level.php">Level</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="equipment.php">Equipment</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <header class="bg-primary text-white">
    <div class="container text-center"></div>
  </header>

  <section id="about">
    <div class="container">
		
	<form action="<?php echo ($_SERVER["PHP_SELF"])?>" method="POST" id="needs-validation" novalidate> 
	  <input name="ID1" type="hidden" value="<?= clean_output($exercise); ?>" >
		
      <div class="row">
        <div class="col-lg-8 mx-auto">
 
		<h2>Level for <?php echo $exercise_name?></h2>
		<table class="table">
	
					<?php echo $page ?>

		</table>

        </div>
      </div>

	<div class="row">  
		<div class="col-sm-6 col-md-6 col-xs-12">  
			<div class="float-right">  
				 <button class="btn btn-primary rounded-0" type="submit" name='cancel' id="cancel">Cancel</button> <button class="btn btn-primary rounded-0" type="submit" name='submit' id="submit">Submit</button>  
			</div>                            
		</div>  
	</div>  


      
 	</form>
     
    </div>
  </section>


  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; StriveHive 2021</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="../js/scrolling-nav.js"></script>

</body>

</html>
