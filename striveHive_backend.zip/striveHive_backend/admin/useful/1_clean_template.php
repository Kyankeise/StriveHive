<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>StriveHive</title>

  <!-- Bootstrap core CSS -->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="../css/scrolling-nav.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="index.php">StriveHive : Admin</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="search.php">Search</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="workout.php">Workout</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="exercise.php">Exercise</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="muscle.php">Muscle</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="category.php">Category</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="level.php">Level</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="equipment.php">Equipment</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="measurement.php">Measurement</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <header class="bg-primary text-white">
    <div class="container text-center"></div>
  </header>

  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">

		<h2>Welcome</h2>
		
		<p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean augue elit, convallis sed urna vitae, pellentesque egestas neque. Cras in magna eget neque consequat eleifend interdum ut ligula. Nunc vestibulum velit est. Integer convallis vestibulum dictum. Vivamus semper tempus placerat. Nam auctor fermentum mauris nec tempus. Integer aliquet tellus mauris, in eleifend sem vehicula a.</p>
		<p>Praesent nisi quam, scelerisque in felis in, vestibulum cursus ipsum. Morbi maximus sit amet orci nec lacinia. Fusce aliquet odio et ipsum ultricies ullamcorper. Nam sagittis nulla sem, nec euismod risus cursus at. Pellentesque aliquam tempus erat, quis ultrices ipsum congue in. Nulla facilisi. Quisque cursus eu erat vitae blandit. Etiam dictum, lacus et mollis lacinia, tellus quam ultrices enim, vitae porttitor velit erat non velit. Mauris sed leo lectus. In hac habitasse platea dictumst.</p>
		<p>Donec eu dolor ac tellus ornare pharetra. Nam tempor dignissim porta. Vivamus eros mi, condimentum in orci et, finibus laoreet justo. Sed id luctus elit. Ut hendrerit libero at ligula pharetra, id commodo ipsum convallis. Donec fringilla ac libero sit amet porttitor. Fusce et purus ligula. Nullam congue eu sapien gravida molestie. Suspendisse tristique malesuada feugiat.</p>
		<p>Cras vitae pulvinar ante, non vestibulum ante. Pellentesque nec maximus dui. Aliquam imperdiet congue ex. Phasellus eget quam non odio cursus tincidunt. Curabitur semper porttitor justo in rhoncus. Pellentesque fermentum non erat sit amet elementum. Nam consequat lorem diam. Ut sed est egestas, placerat enim at, congue risus. Etiam viverra, dui ac laoreet placerat, nulla arcu maximus ligula, vitae faucibus est dui eget nulla.</p>

        </div>
      </div>
    </div>
  </section>


  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; StriveHive 2021</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="../js/scrolling-nav.js"></script>

</body>

</html>
