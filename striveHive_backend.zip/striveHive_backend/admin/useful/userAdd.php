<?php

include("../admin/include/my_vars.php");
include("../admin/include/my_db.php");
include("../admin/include/my_functions.php");

// validate user
// -------------

	is_valid_user();

	$script_title1 = "Member - Add"; 	
	$script_title2 = "Member details";


// process if submit or cancel button is pressed
// ---------------------------------------------
	if ( isset($_POST['submit']) || isset($_POST['cancel'] )  ) {


				// return if cancelled
				// --------------------
					if (  isset($_POST['cancel'])  ) {

									header( "Location: users.php" );
									exit;
					}


				// retrieve input details from form
				// --------------------------------
					$name	 	= $_POST['f_name'];
					$email	 	= $_POST['f_email'];
					$password 	= $_POST['f_password'];
					$paid	  	= $_POST['f_paid'];
					$recvmail  	= $_POST['f_recvmail'];
			

				// validate input
				// --------------
					if (!$name)  $error .= "001  - Please enter a valid name to proceed. <br />";
					if (!$email)  $error .= "002  - Please enter a email name to proceed. <br />";
					if (!is_valid_email($email)) $error .= "002.1 - Please enter a proper email address to procced. <br />";
					if (!$password)   $error .= "003  - Please enter a password to proceed. <br />";
					if (!$recvmail)   $error .= "004  - Please enter receive mail to proceed. <br />";
					if (!$paid)   $error .= "005  - Please enter memebership paid (yes/no)to proceed. <br />";

					if ( strlen($name) > 150 ) $error .= "006 - Validation Error: Maximum length of name is 150 characters. Amend to proceed.<br />";
					if ( strlen($email) > 255 ) $error .= "007 - Validation Error: Maximum length of email is 255 characters. Amend to proceed.<br />";

					

				
				// insert if no errors were found
				// ------------------------------
					if (!$error) {
							$password =  hash('sha256', $password); 			

							
							$query = sprintf("INSERT INTO user ( user_name, user_email, user_password, user_receive_mail, user_access_key, user_paid) values(%s, %s, %s, %s, %s, %s)",
								clean_input( $name ),
								clean_input( $email ),
								clean_input( $password ),
								clean_input( $recvmail ),
								'98',
								clean_input( $paid )
								);

							$result = $db->query($query);

							header( "Location: users.php" );
							exit;

					}
					else {
							displayError( $error );
							exit;
					}

	}

	

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport"    content="width=device-width, initial-scale=1.0">
	<meta name="description" content="Peper Harow Park fly fishers is a friendly, private members fishing club situated between Guildford &amp; Godalming in Surrey, just off the A3. ">
	<meta name="keywords"    content="farnham, guildford, godalming, fly fishing, trout fishing, south east london, london, fishing club">
	
	<title>Admin Only</title>

	<link rel="shortcut icon" href="../assets/images/gt_favicon.png">
	<link rel="stylesheet" media="screen" href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,700">
	<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="../assets/css/font-awesome.min.css">

	<!-- Custom styles for our template -->
	<link rel="stylesheet" href="../assets/css/bootstrap-theme.css" media="screen" >
	<link rel="stylesheet" href="../assets/css/main.css">
	
	<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
	<script src="../assets/js/html5shiv.js"></script>
	<script src="../assets/js/respond.min.js"></script>
	<![endif]-->
</head>

<body>
<!-- Fixed navbar -->
	<div class="navbar navbar-inverse navbar-fixed-top headroom" >
		<div class="container">
			<div class="navbar-header">
				<!-- Button for smallest screens -->
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse"><span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
				<a class="navbar-brand" href="../index.html"><img src="../assets/images/logo3.png" alt="Progressus HTML5 template"></a>
			</div>
			<div class="navbar-collapse collapse">
				<ul class="nav navbar-nav pull-right">
					<li><a href="index.php">Admin</a></li>
					<li class="active"><a href="users.php">Member List</a></li>
					<li><a href="gallery.php">Image Gallery</a></li>
					<li><a href="working.php">Working Parties</a></li>
					<li><a href="document.php">Documents</a></li>
					<li><a href="comms.php">Communications</a></li>
				</ul>
			</div><!--/.nav-collapse -->
		</div>
	</div> 
	<!-- /.navbar -->


	<header id="head" class="secondary"></header>

	<!-- container -->
	<div class="container">

		<div class="row">
			
			<!-- Article main content -->
			<article class="col-xs-12 maincontent">
				<header class="page-header">
					<h1 class="page-title">Add New Member</h1>
				</header>
				
				<div class="col-md-6 col-md-offset-3 col-sm-8 col-sm-offset-2">
					<div class="panel panel-default">
						<div class="panel-body">

							<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST" enctype="multipart/form-data">

								<fieldset>

								<h3><?=$script_title2 ?></h3>

								<table>
								<tr>
								<th>Name:</th>
								<td><input id="f_name" name="f_name" type="input" tabindex="1" /></td>
								</tr>

								<tr>
								<th>Email:</th>
								<td><input id="f_email" name="f_email" type="input" tabindex="2" /></td>
								</tr>

								<tr>
								<th>Password:</th>
								<td><input id="f_password" name="f_password" type="input" tabindex="3" /></td>
								</tr>

								<tr>
								<th>Membership Paid:</th>
								<td><select name="f_paid"> <option value="YES">YES</option> <option value="NO">NO</option></select>  </td>
								</tr>

								<tr>
								<th>Receive Mail:</th>
								<td><select name="f_recvmail"> <option value="YES">YES</option> <option value="NO">NO</option></select>  </td>
								</tr>

								<tr>
								<th>&nbsp;</th>
								<td>&nbsp;</td>
								</tr>
								
								<tr>
								<th>&nbsp;</th>
								<td><input type="Submit" value="Save" name="submit"  tabindex="6" /><input type="Submit" value="Cancel" name="cancel" tabindex="6" /></td>
								</tr>


								</table>
								</fieldset>
								</form>

						
						</div>
					</div>

				</div>
				
			</article>
			<!-- /Article -->

		</div>
	</div>	<!-- /container -->
	

	<footer id="footer">
		<div class="footer2">
			<div class="container">
				<div class="row">				
					<div class="col-md-12 widget">
						<div class="widget-body">
							<p><center>&copy; Peper Harow Park Fly Fishers 2015,  All rights reserved. Designed, built and hosted by <a href="http://www.range93.com/" >RANGE93.COM</a></center></p>
						</div>
					</div>
				</div> <!-- /row of widgets -->
			</div>
		</div>
	</footer>	
		




	<!-- JavaScript libs are placed at the end of the document so the pages load faster -->
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
	<script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
	<script src="../assets/js/headroom.min.js"></script>
	<script src="../assets/js/jQuery.headroom.min.js"></script>
	<script src="../assets/js/template.js"></script>
</body>
</html>

