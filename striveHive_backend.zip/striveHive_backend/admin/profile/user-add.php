<?php

    // parse includes
    // --------------
 			include("../../include/my_vars.php");
			include("../../include/my_db.php");
			include("../../include/my_functions.php");


    // process, if user pressed 'submit'
    //----------------------------------
        if ( isset($_POST['submit']) ) {
 

            // retrieve details from input
            //----------------------------------
                $name   = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
                $email  = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
                $phone  = filter_var($_POST['phone'], FILTER_SANITIZE_STRING);
                $password  = filter_var($_POST['password'], FILTER_SANITIZE_STRING);

			// if name not provided
			// -----------------------------
				if (empty( trim($name) )) {
					$errmsg .= "Please enter a valid name to proceed";
				}

			// if email & phone not provided
			// -----------------------------
				if (!$email && !$phone) {
					$errmsg = "Please enter a valid email and phone to proceed";
				}

			// validate 
			// --------
				if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
					$errmsg .= "Invalid email format. Amend to proceed";
				}


				$pattern = "/^(\+44\s?7\d{3}|\(?07\d{3}\)?)\s?\d{3}\s?\d{3}$/";
				if(preg_match($pattern,$phone) ) {
					$errmsg .= "Invalid phone number. Amend to proceed";
				}


				if ( empty($password) ) {
					$errmsg .= "A valid password is required.";
				}

				if ( strlen($password) < 8 ) {
					$errmsg .= "Password length of 8 or more is required.";
				}

 //print_r(compact(array_keys(get_defined_vars()))); exit;
        
			// if valid 
			// -------- 
				if( !$errmsg ) {

					$query   = sprintf("INSERT INTO user ( user_last_created ) values( now() ) " );
					$result  = $db->query($query) ;
					$last_id = $db->lastid();

					$password = password_hash($password, PASSWORD_DEFAULT);
					$query = sprintf("INSERT INTO contact ( contact_user_id, contact_name, contact_email, contact_phone, contact_password ) values( %s, %s, %s, %s, '%s' )", $last_id, clean_input($name), clean_input($email), $phone, $password );
					$result = $db->query($query);

					$query   = sprintf("INSERT INTO statistic ( statistic_user_id, statistic_date ) values( $last_id, now() ) " );
					$result  = $db->query($query) ;

					$query   = sprintf("INSERT INTO intention ( intention_user_id, intention_date ) values( $last_id, now() ) " );
					$result  = $db->query($query) ;

					$query   = sprintf("INSERT INTO motivation ( motivation_user_id, motivation_date ) values( $last_id, now() ) " );
					$result  = $db->query($query) ;

					$query   = sprintf("INSERT INTO confidence ( confidence_user_id, confidence_date ) values( $last_id, now() ) " );
					$result  = $db->query($query) ;


					header ("Location: user.php");                     
					exit;
					
				}else {
					
					displayError( $errmsg );
					exit;
						
				}  					
		
		}

?>


<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>StriveHive</title>

  <!-- Bootstrap core CSS -->
  <link href="../../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="../../css/scrolling-nav.css" rel="stylesheet">
	<script type="text/javascript">  
				(function () {  
					'use strict';  
					window.addEventListener('load', function () {  
						var form = document.getElementById('needs-validation');  
						form.addEventListener('submit', function (event) {  
							if (form.checkValidity() === false) {  
								event.preventDefault();  
								event.stopPropagation();  
							} else {
								
							}  
							form.classList.add('was-validated');  
						}, false);  
					}, false);  
				})();  
	 </script>  

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="index.php">StriveHive : Admin</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="hive.php">Hive</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="user.php">User</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="gender.php">Gender</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="action.php">Action</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <header class="bg-primary text-white">
    <div class="container text-center"></div>
  </header>

  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
		<h2>User - Add new - Part 1</h2>
        <form action="<?php echo ($_SERVER["PHP_SELF"])?>" method="POST" id="needs-validation" novalidate> 
          
            <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group">  
                        <label for="action">Name</label>  
                        <input type="name" name="name" class="form-control" aria-describedby="inputGroupPrepend" required />  
                        <div class="invalid-feedback">  
                            Please enter a valid name.  
                        </div>  

                    </div>  
                </div>  
             </div>  
        
            <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group">  
                        <label for="action">Email</label>  
                        <input type="email" name="email" class="form-control" aria-describedby="inputGroupPrepend" required />  
                        <div class="invalid-feedback">  
                            Please enter a valid email.  
                        </div>  

                    </div>  
                </div>  
             </div>  

            <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group">  
                        <label for="action">Phone</label>  
                        <input type="text" name="phone" class="form-control" aria-describedby="inputGroupPrepend" required />  
                        <div class="invalid-feedback">  
                            Please enter a valid phone number.  
                        </div>  

                    </div>  
                </div>  
             </div>  

           <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group">  
                        <label for="action">Password</label>  
                        <input type="password" name="password" class="form-control" aria-describedby="inputGroupPrepend" required />  
                        <div class="invalid-feedback">  
                            Please enter a valid password.  
                        </div>  

                    </div>  
                </div>  
             </div>  


            <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="float-right">  
                         <button class="btn btn-primary rounded-0" type="submit" name='submit' id="submit">Submit</button>  
                    </div>                            
                </div>  
            </div>  
        </form>  


        </div>
      </div>
    </div>
  </section>


  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; StriveHive 2021</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="../../vendor/jquery/jquery.min.js"></script>
  <script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="../../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="../../js/scrolling-nav.js"></script>

</body>

</html>
