<?php

    // parse includes
    // --------------
 			include("../include/my_vars.php");
			include("../include/my_db.php");
			include("../include/my_functions.php");
			include("../include/ex_files.php") ;


// process if submit or cancel button is pressed
// ---------------------------------------------
 	if ( isset($_POST['submit']) || isset($_POST['cancel'])   ) {


				// return if cancelled
				// --------------------
					if (  isset($_POST['cancel'])  ) {

							header( "Location: question.php" );
							exit;
					}


				// retrieve input details from form
				// --------------------------------
					$question   	= filter_var($_POST['ID1'], FILTER_SANITIZE_STRING);
					$answer_ids 	= $_POST['check_list'];


				// validate question
				// -----------------
					$query = sprintf("SELECT * FROM question WHERE question_id=%s LIMIT 1", clean_input( $question ) );				
					$result = $db->query($query);

				// return if question not found
				// ----------------------------
					if ( count($result) == 0 ) {
						$errmsg = 'Invalid question number - Please retry later';
					} 
					
				// validate answer
				// ----------------
					if (count($answer_ids) == 0){
						$errmsg = 'Please select answer groups to proceed';
					}


				
				// loop and add each mucles in to question-answer table
				// ----------------------------------------------------
					foreach ( $answer_ids as $md ) {

					
						// see if this question-answer
							$query = sprintf("SELECT * FROM question_answer WHERE question_answer_question_id=%s AND question_answer_answer_id=%s LIMIT 1", clean_input( $question ), clean_input( $md ) );				
							$result = $db->query($query);

							if( count( $result ) == 0 ) {
								
								$query = sprintf("INSERT INTO question_answer ( question_answer_question_id, question_answer_answer_id ) values(%s, %s)", clean_input( $question ), clean_input(  $md ) );
								$result = $db->query($query);

							}
						
						
					}
					
					$location = 'question-detail.php?ID=' .$question;
					header( "Location: $location" );
					exit;
				
//print_r(compact(array_keys(get_defined_vars()))); exit;

 
	}







	// get the input and clean
	// --------------------       
			if ($_GET['ID1'] != "") {
				$_GET['ID1'] = filter_var($_GET['ID1'], FILTER_SANITIZE_STRING);
			}


	// retrieve input and validate
	// ---------------------------- 	
			$question = $_GET['ID1'];
			$query = sprintf("SELECT * FROM question WHERE question_id=%s LIMIT 1", clean_input( $question ) );				
			$result = $db->query($query);

		// return if question not found
		// ----------------------------
			if ( count($result) == 0 ) {
                header ("Location: question.php");                     
                exit;
			} 
		
		// question name
		// -------------		
			$question_name = $result[0]->question_name ;

		// get existing answers for this question
		// --------------------------------------
			$answer_array = getanswer( $question );

	// setup query & read record
	// -------------------------
			$query  = "SELECT * FROM answer ORDER BY answer_id";
			$result = $db->query($query);
			$page = '';

			if ( count($result) > 0 ) {

 					foreach( $result as $i ) {
						$key = array_search($i->answer_id, array_column($answer_array, 'answer_id'));	
						if (false !== $key) $chk = 'checked'; else $chk = '';
						
						$page .= '<div class="form-check"><input class="form-check-input" name="check_list[]" type="checkbox" value="' . $i->answer_id .'"' .$chk   .'><label class="form-check-label">' .$i->answer_name	.'</label></div>';
					}

			}
//print_r(compact(array_keys(get_defined_vars()))); exit;

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>StriveHive</title>

  <!-- Bootstrap core CSS -->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="../css/scrolling-nav.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="index.php">StriveHive : Admin</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="hive.php">Hive</a></li>
        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="user.php">User</a></li>
        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="gender.php">Gender</a></li>
        <li class="nav-item"><a class="nav-link js-scroll-trigger" href="question.php">Question</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <header class="bg-primary text-white">
    <div class="container text-center"></div>
  </header>

  <section id="about">
    <div class="container">
		
	<form action="<?php echo ($_SERVER["PHP_SELF"])?>" method="POST" id="needs-validation" novalidate> 
	  <input name="ID1" type="hidden" value="<?= clean_output($question); ?>" >
		
      <div class="row">
        <div class="col-lg-8 mx-auto">
 
		<h2>Answer for <?php echo $question_name?></h2>
		<table class="table">
	
					<?php echo $page ?>

		</table>

        </div>
      </div>

	<div class="row">  
		<div class="col-sm-6 col-md-6 col-xs-12">  
			<div class="float-right">  
				 <button class="btn btn-primary rounded-0" type="submit" name='cancel' id="cancel">Cancel</button> <button class="btn btn-primary rounded-0" type="submit" name='submit' id="submit">Submit</button>  
			</div>                            
		</div>  
	</div>  


      
 	</form>
     
    </div>
  </section>


  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; StriveHive 2021</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="../js/scrolling-nav.js"></script>

</body>

</html>
