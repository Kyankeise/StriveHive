<?php


	include("../../include/my_vars.php");
	include("../../include/my_db.php");
	include("../../include/my_functions.php");


// process if submit or cancel button is pressed
// ---------------------------------------------
 	if ( isset($_POST['submit']) || isset($_POST['cancel'])   ) {


				// return if cancelled
				// --------------------
					if (  isset($_POST['cancel'])  ) {

							header( "Location: answer.php" );
							exit;
					}


				// retrieve input details from form
				// --------------------------------
					$answer_id   = $_POST['ID'];
					$answer_name = $_POST['answer'];


				// validate input
				// --------------
					if (!$answer_name)  $error .= "001  - Please enter a valid name to proceed. <br />";
					if ($answer_name)   {
						if ( strlen($answer_name) > 120 ) $error .= "003 - Validation Error: Maximum length of password is 120 characters. Amend to proceed.<br />";
					}


				// if errors, inform user
				// ----------------------
					if ($error) {

							displayError( $error );
							exit;

					}


				// save details to table
				// ---------------------
					if ($answer_name) {
						$query = sprintf("UPDATE answer SET  answer_name=%s WHERE answer_id=%s LIMIT 1",
								clean_input( $answer_name ),
								clean_input( $answer_id ) );
						$result = $db->query($query);
					} 

				// save only, return
				// -----------------
					if (  isset($_POST['submit'])  ) {
								header( "Location: answer.php" );
								exit;
					}





	}



// retrieve page id
// ----------------
	$answer_id = $_GET['ID'];


// retrieve page details
// ----------------------
	$query = sprintf("SELECT * FROM answer WHERE answer_id=%s LIMIT 1",
					clean_input( $answer_id) );
	$result = $db->query($query);


// record not found, return
// ------------------------
	if (count($result) == 0 ) {
		header( "Location: answer.php");
		exit;
	}

	
?>


<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>StriveHive</title>

  <!-- Bootstrap core CSS -->
  <link href="../../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="../../css/scrolling-nav.css" rel="stylesheet">
	<script type="text/javascript">  
				(function () {  
					'use strict';  
					window.addEventListener('load', function () {  
						var form = document.getElementById('needs-validation');  
						form.addEventListener('submit', function (event) {  
							if (form.checkValidity() === false) {  
								event.preventDefault();  
								event.stopPropagation();  
							} else {
								
							}  
							form.classList.add('was-validated');  
						}, false);  
					}, false);  
				})();  
	 </script>  

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="index.php">StriveHive : Admin</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="hive.php">Hive</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="user.php">User</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="gender.php">Gender</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="answer.php">answer</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <header class="bg-primary text-white">
    <div class="container text-center"></div>
  </header>

  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
		<h2>answer - Edit</h2>

        <form answer="<?php echo ($_SERVER["PHP_SELF"])?>" method="POST" id="needs-validation" novalidate> 

			<input name="ID" type="hidden" value="<?= clean_output($result[0]->answer_id); ?>" >
          
        
            <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group">  
                        <label for="answer">answer Description</label>  
                        <input type="text" name="answer" value="<?= clean_output($result[0]->answer_name); ?>" class="form-control" aria-describedby="inputGroupPrepend" required />  
                        <div class="invalid-feedback">  
                            Please enter a valid answer description.  
                        </div>  

                    </div>  
                </div>  
             </div>  


            <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="float-right">  
                         <button class="btn btn-primary rounded-0" type="submit" name='cancel' id="cancel">Cancel</button> <button class="btn btn-primary rounded-0" type="submit" name='submit' id="submit">Submit</button>  
                    </div>                            
                </div>  
            </div>  
        </form>  

        </div>
      </div>
    </div>
  </section>


  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; StriveHive 2021</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="../../vendor/jquery/jquery.min.js"></script>
  <script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="../../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="../../js/scrolling-nav.js"></script>

</body>

</html>



			
