<?php


	include("../../include/my_vars.php");
	include("../../include/my_db.php");
	include("../../include/my_functions.php");


// process if submit or cancel button is pressed
// ---------------------------------------------
 	if ( isset($_POST['submit']) || isset($_POST['cancel'])   ) {


				// return if cancelled
				// --------------------
					if (  isset($_POST['cancel'])  ) {

							header( "Location: user.php" );
							exit;
					}


				// retrieve input details from form
				// --------------------------------
					$user_id     = filter_var($_POST['ID'], FILTER_SANITIZE_STRING);;
					$weight		 = filter_var($_POST['weight'], FILTER_SANITIZE_STRING);;
					$height	 	 = filter_var($_POST['height'], FILTER_SANITIZE_STRING);;
					$intention	 = filter_var($_POST['intention'], FILTER_SANITIZE_STRING);;
					$motivation	 = filter_var($_POST['motivation'], FILTER_SANITIZE_STRING);;
					$confidence	 = filter_var($_POST['confidence'], FILTER_SANITIZE_STRING);;


				// validate input
				// --------------

					if (empty( trim($weight) )) {
						$error .= "Please enter a valid weight in kg to proceed <br/>";
					}

					if (empty( trim($height) )) {
						$error .= "Please enter a valid height in cm to proceed <br/>";
					}

					
					if (strlen($intention) >1000 ) {
						$error .= "Dude, we just want your intentions, not your life story. Stay focused!! <br/>";
					}
					
					if (strlen($motivation) >1000 ) {
						$error .= "Dude, we just want your motivations. Stay focused!! Do it again in less than 1000 characters <br/>";
					}
					
					if (strlen($confidence) >1000 ) {
						$error .= "Dude, we just want you to write about confidence, not your issues. Geez. Stay focused and do it again!! <br/>";
					}
					
					
				// if errors, inform user
				// ----------------------
					if ($error) {

							displayError( $error );
							exit;

					}


				// save details to static
				// ----------------------

					$query = sprintf("SELECT * FROM statistic WHERE statistic_user_id=%s LIMIT 1", clean_input( $user_id) );
					$result = $db->query($query);
					
					$query = sprintf("UPDATE statistic SET statistic_height=%s, statistic_weight=%s, statistic_date='now()' WHERE statistic_user_id=%s LIMIT 1",
									clean_input( $height ),
									clean_input( $weight ),
									clean_input( $user_id )
									);
					$result = $db->query($query);					
					
					
					$query = sprintf("UPDATE statistic SET statistic_height=%s, statistic_weight=%s, statistic_date=now() WHERE statistic_user_id=%s LIMIT 1",
							clean_input( $height ),
							clean_input( $weight ),
							clean_input( $user_id )
							);
					$result = $db->query($query);
 
					$query = sprintf("UPDATE intention SET intention_name=%s, intention_date=now() WHERE intention_user_id=%s LIMIT 1",
							clean_input( $intention ),
							clean_input( $user_id )
							);
					$result = $db->query($query);

					$query = sprintf("UPDATE motivation SET motivation_name=%s,  motivation_date=now() WHERE  motivation_user_id=%s LIMIT 1",
							clean_input( $motivation ),
							clean_input( $user_id )
							);
					$result = $db->query($query);

					$query = sprintf("UPDATE confidence  SET confidence_name=%s, confidence_date=now() WHERE confidence_user_id=%s LIMIT 1",
							clean_input( $confidence  ),
							clean_input( $user_id)
							);
					$result = $db->query($query);
 


				// save only, return
				// -----------------
					if (  isset($_POST['submit'])  ) {
								header( "Location: user.php" );
								exit;
					}



	}



// retrieve page id
// ----------------
	$user_id = $_GET['ID'];


// retrieve page details
// ----------------------
	$query = sprintf("SELECT * FROM user WHERE user_id=%s LIMIT 1",	clean_input( $user_id) );
	$user = $db->query($query);

// record not found, return
// ------------------------
	if (count($user) == 0 ) {
		header( "Location: user.php");
		exit;
	}

	if ( $user[0]->user_measurement == 'I') {
			$measure = 'Imperial';
			
	}

// retrieve statistic
// ------------------
	$query = sprintf("SELECT * FROM statistic WHERE statistic_user_id=%s LIMIT 1", clean_input( $user_id) );
	$statistic = $db->query($query);

// retrieve intention
// ----------------
	$query = sprintf("SELECT * FROM intention WHERE intention_user_id=%s LIMIT 1", clean_input( $user_id) );
	$intention = $db->query($query);

// retrieve motivation
// -------------------
	$query = sprintf("SELECT * FROM motivation WHERE motivation_user_id=%s LIMIT 1", clean_input( $user_id) );
	$motivation = $db->query($query);

// retrieve motivation
// -------------------
	$query = sprintf("SELECT * FROM confidence WHERE confidence_user_id=%s LIMIT 1", clean_input( $user_id) );
	$confidence = $db->query($query);

	
//print_r(compact(array_keys(get_defined_vars()))); exit;	

function convert_to_cm($feet, $inches = 0) {

	    $inches = ($feet * 12) + $inches;
	    return (int) round($inches / 0.393701);

}

function convert_to_inches($cm) {

	    $inches = round($cm * 0.393701);

	    $result = [
	        'ft' => intval($inches / 12),
	        'in' => $inches % 12,
	    ];
	 
	    return $result;
}
	
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>StriveHive</title>

  <!-- Bootstrap core CSS -->
  <link href="../../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="../../css/scrolling-nav.css" rel="stylesheet">
	<script type="text/javascript">  
				(function () {  
					'use strict';  
					window.addEventListener('load', function () {  
						var form = document.getElementById('needs-validation');  
						form.addEventListener('submit', function (event) {  
							if (form.checkValidity() === false) {  
								event.preventDefault();  
								event.stopPropagation();  
							} else {
								
							}  
							form.classList.add('was-validated');  
						}, false);  
					}, false);  
				})();  
	 </script>  

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="index.php">StriveHive : Admin</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="hive.php">Hive</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="user.php">User</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="gender.php">Gender</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="action.php">Action</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <header class="bg-primary text-white">
    <div class="container text-center"></div>
  </header>

  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
		<h2>User - Edit part 3</h2>

        <form action="<?php echo ($_SERVER["PHP_SELF"])?>" method="POST" id="needs-validation" novalidate> 

			<input name="ID" type="hidden" value="<?= clean_output($user[0]->user_id); ?>" >
          
			 
			 
             <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group">  
                        <label for="action">Height (cm)</label>  
                        <input type="number" name="height" class="form-control" aria-describedby="inputGroupPrepend" value="<?= clean_output($statistic[0]->statistic_height); ?>" required />  
                        <div class="invalid-feedback">  
                            Please enter a valid height in cm.  
                        </div>  
                    </div>  
                </div>  
 
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group">  
                         <label for="action">Weight (kg)</label>  
                        <input type="number" name="weight" class="form-control" aria-describedby="inputGroupPrepend" value="<?= clean_output($statistic[0]->statistic_weight); ?>" required />  
                        <div class="invalid-feedback">  
                            Please enter a valid weight in kg.  
                        </div>  

                    </div>  
                </div>  
             </div>  


             <div class="row">  
                <div class="col-sm-12 col-md-12 col-xs-12">  
                    <div class="form-group">  
                        <label for="action">Intention</label>  
						<textarea class="form-control" name="intention"  aria-label="With textarea"><?= clean_output($intention[0]->intention_name); ?></textarea>
                        <div class="invalid-feedback">  
                            Please enter your intention.  
                        </div>  

                    </div>  
                </div>  
 
             </div>  

             <div class="row">  
                <div class="col-sm-12 col-md-12 col-xs-12">  
                    <div class="form-group">  
                        <label for="action">Motivation</label>  
						<textarea class="form-control" name="motivation"  aria-label="With textarea"><?= clean_output($motivation[0]->motivation_name); ?></textarea>
                        <div class="invalid-feedback">  
                            Please enter your motivation.  
                        </div>  

                    </div>  
                </div>  
 
             </div>  

             <div class="row">  
                <div class="col-sm-12 col-md-12 col-xs-12">  
                    <div class="form-group">  
                        <label for="action">Confidence</label>  
						<textarea class="form-control" name="confidence"  aria-label="With textarea"><?= clean_output($confidence[0]->confidence_name); ?></textarea>
                        <div class="invalid-feedback">  
                            Please enter something about your confidence.  
                        </div>  

                    </div>  
                </div>  
 
             </div>  











            <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="float-right">  
                         <button class="btn btn-primary rounded-0" type="submit" name='cancel' id="cancel">Cancel</button> <button class="btn btn-primary rounded-0" type="submit" name='submit' id="submit">Submit</button>  
                    </div>                            
                </div>  
            </div>  
        </form>  

        </div>
      </div>
    </div>
  </section>


  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; StriveHive 2021</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="../../vendor/jquery/jquery.min.js"></script>
  <script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="../../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="../../js/scrolling-nav.js"></script>

</body>

</html>



			
