<?php


	include("../../include/my_vars.php");
	include("../../include/my_db.php");
	include("../../include/my_functions.php");


// process if submit or cancel button is pressed
// ---------------------------------------------
 	if ( isset($_POST['submit']) || isset($_POST['cancel'])   ) {


				// return if cancelled
				// --------------------
					if (  isset($_POST['cancel'])  ) {

							header( "Location: user.php" );
							exit;
					}


				// retrieve input details from form
				// --------------------------------
					$user_id     = filter_var($_POST['ID'], FILTER_SANITIZE_STRING);;
					$gender_name = filter_var($_POST['gender'], FILTER_SANITIZE_STRING);;
					$email 		 = filter_var($_POST['email'], FILTER_SANITIZE_STRING);;
					$phone		 = filter_var($_POST['phone'], FILTER_SANITIZE_STRING);;
					$first_name	 = filter_var($_POST['first_name'], FILTER_SANITIZE_STRING);;
					$last_name	 = filter_var($_POST['last_name'], FILTER_SANITIZE_STRING);;
					$dob		 = filter_var($_POST['dob'], FILTER_SANITIZE_STRING);;
					$gender		 = filter_var($_POST['gender'], FILTER_SANITIZE_STRING);;
					$measure	 = filter_var($_POST['measure'], FILTER_SANITIZE_STRING);;
					$action	 	 = filter_var($_POST['action'], FILTER_SANITIZE_STRING);;
					$notification = filter_var($_POST['notification'], FILTER_SANITIZE_STRING);;
					$photo		  = filter_var($_POST['photo'], FILTER_SANITIZE_STRING);;


				// validate input
				// --------------

					if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
						$error .= "Invalid email format. Amend to proceed <br/>";
					}


					$pattern = "/^(\+44\s?7\d{3}|\(?07\d{3}\)?)\s?\d{3}\s?\d{3}$/";
					if(preg_match($pattern,$phone) ) {
						$error .= "Invalid phone number. Amend to proceed <br/>";
					}

					if (empty( trim($first_name) )) {
						$error .= "Please enter a valid first name to proceed <br/>";
					}

					if (empty( trim($last_name) )) {
						$error .= "Please enter a valid last name to proceed <br/>";
					}

					if (empty( trim($dob) )) {
						$$error .= "Please enter a valid birthday <br/> ";
					} else {
						$dat_arr  = explode('-', $dob);
						if (!checkdate($dat_arr[1], $dat_arr[2], $dat_arr[0])) {
							$error .= "Invalid date of birth <br/>" ;
						}
					}

					
				// age
				// ---
					$age = intval(substr(date('Ymd') - date('Ymd', strtotime($dob)), 0, -4));
					if ($age <18) {
						$error .= "The app is for ages of 18 or over only <br/>" ;
					}

				// if errors, inform user
				// ----------------------
					if ($error) {

							displayError( $error );
							exit;

					}

//								user_1st_name, user_2nd_name, user_DOB, user_gender, user_measurement, user_action, user_notification, user_photo,

				// save details to table
				// ---------------------
					if ($gender_name) {
						$query = sprintf("UPDATE user SET user_1st_name=%s, user_2nd_name=%s, user_DOB='%s', user_gender=%s, user_measurement=%s, user_action=%s, user_notification=%s, user_photo=%s  WHERE user_id=%s LIMIT 1",
								clean_input( $first_name ),
								clean_input( $last_name ),
								date( "Y-m-d",strtotime($dob) ),
								clean_input( $gender ),
								clean_input( $measure ),
								clean_input( $action ),
								clean_input( $notification ),
								clean_input( $photo ),
								clean_input( $user_id ) );
								
						$result = $db->query($query);
					} 

				// save only, return
				// -----------------
					if (  isset($_POST['submit'])  ) {
								$location = "Location: user-edit-2.php?ID=" .$user_id ;
								header( $location );
								exit;
					}





	}



// retrieve page id
// ----------------
	$user_id = $_GET['ID'];


// retrieve page details
// ----------------------
	$query = sprintf("SELECT * FROM user WHERE user_id=%s LIMIT 1",	clean_input( $user_id) );
	$user = $db->query($query);

// record not found, return
// ------------------------
	if (count($user) == 0 ) {
		header( "Location: user.php");
		exit;
	}

// retrieve contact
// ----------------
	$query = sprintf("SELECT * FROM contact WHERE contact_user_id=%s LIMIT 1", clean_input( $user_id) );
	$contact = $db->query($query);
	
// retrieve action
// ---------------
	$query  = "SELECT * FROM action ORDER BY action_id";
	$result = $db->query($query); 
	$action_page = '';

	if ( count($result) > 0 ) {
			foreach( $result as $i ) {
				if( $i->action_id == $user[0]->user_action ) {
					$action_page .= '<option value="' .$i->action_id .'" selected>' .clean_output($i->action_name) .'</option>';

					}
				else {
					$action_page .= '<option value="' .$i->action_id .'">' .clean_output($i->action_name) .'</option>';
				}
			}
	}
//print_r(compact(array_keys(get_defined_vars()))); exit;	
// retrieve gender
// ---------------
	$query  = "SELECT * FROM gender ORDER BY gender_name";
	$result = $db->query($query); 
	$gender_page = '';

	if ( count($result) > 0 ) {
			foreach( $result as $i ) {
				if( $i->gender_id == $user[0]->user_gender ) {
					$gender_page .= '<option value="' .$i->gender_id .'" selected>' .clean_output($i->gender_name) .'</option>';

					}
				else {
					$gender_page .= '<option value="' .$i->gender_id .'">' .clean_output($i->gender_name) .'</option>';
				}
			}
	}
	
// measurement
// -----------
	$measure_page = '';
	if ( $user[0]->user_measurement == 'I' ) {
				$measure_page =	'<option value="M" >Metric</option><option value="I" selected>Imperial</option> ';				  
	} else {
				$measure_page =	'<option value="M" selected>Metric</option><option value="I">Imperial</option> ';				  
		
	}
// notification
// ------------
	$notification_page = '';
	if ( $user[0]->user_notification == 'E') {
				$notification_page = '<option value="E" selected>Email</option><option value="S">SMS</option> ';				  
	} else {
				$notification_page = '<option value="E" >Email</option><option value="S" selected>SMS</option> ';				  
	}
	
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>StriveHive</title>

  <!-- Bootstrap core CSS -->
  <link href="../../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="../../css/scrolling-nav.css" rel="stylesheet">
	<script type="text/javascript">  
				(function () {  
					'use strict';  
					window.addEventListener('load', function () {  
						var form = document.getElementById('needs-validation');  
						form.addEventListener('submit', function (event) {  
							if (form.checkValidity() === false) {  
								event.preventDefault();  
								event.stopPropagation();  
							} else {
								
							}  
							form.classList.add('was-validated');  
						}, false);  
					}, false);  
				})();  
	 </script>  

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="index.php">StriveHive : Admin</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="hive.php">Hive</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="user.php">User</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="gender.php">Gender</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="action.php">Action</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <header class="bg-primary text-white">
    <div class="container text-center"></div>
  </header>

  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
		<h2>User - Edit part 2</h2>

        <form action="<?php echo ($_SERVER["PHP_SELF"])?>" method="POST" id="needs-validation" novalidate> 

			<input name="ID" type="hidden" value="<?= clean_output($user[0]->user_id); ?>" >
          
             <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group">  
                        <label for="action">Name</label>  
                        <input type="name" name="name" class="form-control" aria-describedby="inputGroupPrepend" value="<?= clean_output($contact[0]->contact_name); ?>" required />  
                        <div class="invalid-feedback">  
                            Please enter a valid name.  
                        </div>  

                    </div>  
                </div>  
			 </div>
			 
			 
             <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group">  
                        <label for="action">Email</label>  
                        <input type="email" name="email" class="form-control" aria-describedby="inputGroupPrepend" value="<?= clean_output($contact[0]->contact_email); ?>" required />  
                        <div class="invalid-feedback">  
                            Please enter a valid email.  
                        </div>  

                    </div>  
                </div>  
 
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group">  
                        <label for="action">Phone</label>  
                        <input type="text" name="phone" class="form-control" aria-describedby="inputGroupPrepend" value="<?= clean_output($contact[0]->contact_phone); ?> "  required />  
                        <div class="invalid-feedback">  
                            Please enter a valid phone number.  
                        </div>  

                    </div>  
                </div>  
             </div>  

             <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group">  
                        <label for="action">First Name</label>  
                        <input type="text" name="first_name" class="form-control" aria-describedby="inputGroupPrepend" value="<?= clean_output($user[0]->user_1st_name); ?>" required />  
                        <div class="invalid-feedback">  
                            Please enter a valid first name.  
                        </div>  

                    </div>  
                </div>  
 
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group">  
                        <label for="action">Last Name</label>  
                        <input type="text" name="last_name" class="form-control" aria-describedby="inputGroupPrepend" value="<?= clean_output($user[0]->user_2nd_name); ?>" required />  
                        <div class="invalid-feedback">  
                            Please enter a valid last name.  
                        </div>  

                    </div>  
                </div>  
             </div>  

             <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group">  
                        <label for="dob">Birthday</label>  
                        <input type="date" name="dob" class="form-control" aria-describedby="inputGroupPrepend" value=<?= date("Y-m-d", strtotime( $user[0]->user_DOB)); ?> required />  
                        <div class="invalid-feedback">  
                            Please enter a valid date of birth.  
                        </div>  

                    </div>  
                </div>  
 
				<div class="col-lg-6 mx-auto">
					<label class="mr-sm-2" for="gender">Gender</label>
					<select class="custom-select mr-sm-2" id="gender" name="gender">
						<?php echo $gender_page ?>
					</select>
				</div> 

             </div>  


             <div class="row">  
				<div class="col-lg-6 mx-auto">
					<label class="mr-sm-2" for="measure">Measurement</label>
					<select class="custom-select mr-sm-2" id="measure" name="measure">
						<?php echo $measure_page ?>					
					</select>
				</div> 
 				<div class="col-lg-6 mx-auto">
					<label class="mr-sm-2" for="action">Action</label>
					<select class="custom-select mr-sm-2" id="action" name="action">
						<?php echo $action_page ?>
					</select>
				</div> 
 

              </div>  


             <div class="row">  
 				<div class="col-lg-6 mx-auto">
					<label class="mr-sm-2" for="notification">Notification</label>
					<select class="custom-select mr-sm-2" id="notification" name="notification">
						<?php echo	$notification_page ?>
					</select>
				</div> 

 
 
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group">  
                        <label for="action">Photo</label>  
                        <input type="text" name="photo" class="form-control" aria-describedby="inputGroupPrepend"  />  
                        <div class="invalid-feedback">  
                            Please enter a valid photo location.  
                        </div>  

                    </div>  
                </div>  
             </div>  



            <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="float-right">  
                         <button class="btn btn-primary rounded-0" type="submit" name='cancel' id="cancel">Cancel</button> <button class="btn btn-primary rounded-0" type="submit" name='submit' id="submit">Submit</button>  
                    </div>                            
                </div>  
            </div>  
        </form>  

        </div>
      </div>
    </div>
  </section>


  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; StriveHive 2021</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="../../vendor/jquery/jquery.min.js"></script>
  <script src="../../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="../../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="../../js/scrolling-nav.js"></script>

</body>

</html>



			
