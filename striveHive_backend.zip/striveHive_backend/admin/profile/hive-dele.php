<?php

 			include("../../include/my_vars.php");
			include("../../include/my_db.php");
			include("../../include/my_functions.php");


// retrieve page id
// ----------------
		$id = $_GET['ID'];


// delete page
// -----------
		if ($id) {

			$query = sprintf("DELETE FROM hive WHERE hive_id=%s ", clean_input( $id ) );
			$result = $db->query($query);
 			header( "Location: hive.php" );
 			exit;

		}
		else {

			displayError ("Input error. An error had occured while processing your submission. Please retry later.");
			exit;

}
