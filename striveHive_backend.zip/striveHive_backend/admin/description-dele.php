<?php

 			include("../include/my_vars.php");
			include("../include/my_db.php");
			include("../include/my_functions.php");


// retrieve page id
// ----------------
		$id = $_GET['ID'];


// delete page
// -----------
		if ($id) {

			$query = sprintf("DELETE FROM description WHERE description_id=%s ", clean_input( $id ) );
			$result = $db->query($query);
 			header( "Location: description.php" );
 			exit;

		}
		else {

			displayError ("Input error. An error had occured while processing your submission. Please retry later.");
			exit;

}
