<?php

		include("../include/my_vars.php");
		include("../include/my_db.php");
		include("../include/my_functions.php");


// retrieve page id
// ----------------
		$id = $_GET['ID'];


// delete page
// -----------
		if ($id) {

			$query = sprintf("DELETE FROM workout_exercise WHERE workout_exercise_workout_id=%s ", clean_input( $id ) );
			$result = $db->query($query);
			
			$query = sprintf("DELETE FROM workout WHERE workout_id=%s ", clean_input( $id ) );
			$result = $db->query($query);

 			header( "Location: workout.php" );
 			exit;

		}
		else {

			displayError ("Input error. An error had occured while processing your submission. Please retry later.");
			exit;

		}
