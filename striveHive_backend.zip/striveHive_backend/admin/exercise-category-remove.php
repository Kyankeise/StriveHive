<?php

 			include("../include/my_vars.php");
			include("../include/my_db.php");
			include("../include/my_functions.php");


// retrieve page id
// ----------------
		$exercise = filter_var($_GET['ID1'], FILTER_SANITIZE_STRING);
		$category   = filter_var($_GET['ID2'], FILTER_SANITIZE_STRING);

// delete page
// -----------
		if ($exercise && $category) {

			$query = sprintf("DELETE FROM exercise_category WHERE exercise_category_exercise_id=%s AND exercise_category_category_id=%s ", clean_input( $exercise ), clean_input( $category ) );
			$result = $db->query($query);
			
			$location = 'exercise-detail.php?ID=' .$exercise ;
 			header( "Location: $location" );
 			exit;

		}
		else {

			displayError ("Input error. An error had occured while processing your submission. Please retry later.");
			exit;

}
