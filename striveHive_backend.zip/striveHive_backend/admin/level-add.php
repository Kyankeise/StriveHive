<?php

    // parse includes
    // --------------
 			include("../include/my_vars.php");
			include("../include/my_db.php");
			include("../include/my_functions.php");


    // process, if user pressed 'submit'
    //----------------------------------
        if ( isset($_POST['submit']) ) {
 

            // retrieve details from input
            //----------------------------------
                $level  		= filter_var($_POST['level'], FILTER_SANITIZE_STRING);
        
			// if valid muscle
			// ---------------
				if( $level) {

					$query = sprintf("INSERT INTO level ( level_name ) values(%s)",clean_input( $level ) );
					$result = $db->query($query);
					
				}
                
                header ("Location: level.php");                     
                exit;

					
		}


?>


<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>StriveHive</title>

  <!-- Bootstrap core CSS -->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="../css/scrolling-nav.css" rel="stylesheet">
	<script type="text/javascript">  
				(function () {  
					'use strict';  
					window.addEventListener('load', function () {  
						var form = document.getElementById('needs-validation');  
						form.addEventListener('submit', function (event) {  
							if (form.checkValidity() === false) {  
								event.preventDefault();  
								event.stopPropagation();  
							} else {
								
							}  
							form.classList.add('was-validated');  
						}, false);  
					}, false);  
				})();  
	 </script>  

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="index.php">StriveHive : Admin</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="search.php">Search</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="exercise.php">Exercise</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="muscle.php">Muscle</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="category.php">Category</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="level.php">Level</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="equipment.php">Equipment</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <header class="bg-primary text-white">
    <div class="container text-center"></div>
  </header>

  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">
		<h2>Level - Add new</h2>
        <form action="<?php echo ($_SERVER["PHP_SELF"])?>" method="POST" id="needs-validation" novalidate> 
          
        
            <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="form-group">  
                        <label for="level">Level Description</label>  
                        <input type="text" name="level" class="form-control" aria-describedby="inputGroupPrepend" required />  
                        <div class="invalid-feedback">  
                            Please enter a valid Level description.  
                        </div>  

                    </div>  
                </div>  
             </div>  



            <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="float-right">  
                         <button class="btn btn-primary rounded-0" type="submit" name='submit' id="submit">Submit</button>  
                    </div>                            
                </div>  
            </div>  
        </form>  


        </div>
      </div>
    </div>
  </section>


  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; StriveHive 2021</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="../js/scrolling-nav.js"></script>

</body>

</html>
