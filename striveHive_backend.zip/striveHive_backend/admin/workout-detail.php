<?php

    // parse includes
    // --------------
 			include("../include/my_vars.php");
			include("../include/my_db.php");
			include("../include/my_functions.php");

 
	// get the input and clean
	// --------------------       
			if ($_GET['ID'] != "") {
				$_GET['ID'] = filter_var($_GET['ID'], FILTER_SANITIZE_STRING);
			}


	// retrieve input
	// -------------- 	
			$workout_id = $_GET['ID'];
			$page = '';
	
	// if submit pressedd return
	// -------------------------
       if ( isset($_POST['submit']) ) {
			header ( "Location: workout.php" );                     
			exit;
		}

	// select the all records from exercise table
	// ------------------------------------------
			$query = sprintf("SELECT * FROM workout WHERE workout_id=%s LIMIT 1", clean_input( $workout_id ) );				
			$result = $db->query($query);

			if ( count($result) > 0 ) {

					$workout_name	 	  = $result[0]->workout_name ;
					$workout_user_id 	  = $result[0]->workout_user_id ;
					$workout_last_created = $result[0]->workout_last_created;

					$query = sprintf("SELECT * FROM workout_exercise WHERE workout_exercise_workout_id=%s ORDER BY workout_exercise_id ", clean_input( $workout_id ) );				
					$result = $db->query($query);

					if ( count($result) > 0 ) { 
									
						foreach( $result as $i ) {
						
								if($i->workout_exercise_exercise_id) {
									$page .= "<tr>";
									$page .= "<td>" .getExerciseName($i->workout_exercise_exercise_id) ."</td>";
									$page .= "<td><a href='workout-detail-exercise-dele.php?ID=" .$workout_id ."&ID1="  .$i->workout_exercise_id  ."'>&minus;</a></td>";
									$page .= "<td>$i->workout_exercise_set</td>";
									$page .= "<td>$i->workout_exercise_rep</td>";
									$page .= "<td>$i->workout_exercise_weight</td>";
									$page .= "<td>$i->workout_exercise_time</td>";
									$page .= "<td>&nbsp;</td>";
									$page .= "<td>&nbsp;</td>";
									$page .= "</tr>";
								}
								if($i->workout_exercise_workout_child_id) {
									$page .= "<tr>";
									$page .= "<td>&nbsp;</td>";
									$page .= "<td></td>";
									$page .= "<td>&nbsp;</td>";
									$page .= "<td>&nbsp;</td>";
									$page .= "<td>&nbsp;</td>";
									$page .= "<td>&nbsp;</td>";
									$page .= "<td>" .getWorkoutName($i->workout_exercise_workout_child_id) . " </td>";
									$page .= "<td><a href='workout-detail-exercise-dele.php?ID=" .$workout_id ."&ID1="  .$i->workout_exercise_id  ."'>&minus;</a></td>";
	
									$page .= "</tr>";
								}
						
						}
					
					}

				
			}

function getExerciseName ( $exercise_id ) {

	global $db;	
	
	$query = sprintf("SELECT * FROM exercise WHERE exercise_id=%s LIMIT 1", $exercise_id );
	$result = $db->query($query); 
	return clean_output($result[0]->exercise_name);
	
}

function getWorkoutName ( $workout_id ) {

	global $db;	
	
	$query = sprintf("SELECT * FROM workout WHERE workout_id=%s LIMIT 1", $workout_id );
	$result = $db->query($query); 
	return clean_output($result[0]->workout_name);
	
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>StriveHive</title>

  <!-- Bootstrap core CSS -->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="../css/scrolling-nav.css" rel="stylesheet">
	<script type="text/javascript">  
				(function () {  
					'use strict';  
					window.addEventListener('load', function () {  
						var form = document.getElementById('needs-validation');  
						form.addEventListener('submit', function (event) {  
							if (form.checkValidity() === false) {  
								event.preventDefault();  
								event.stopPropagation();  
							} else {
								
							}  
							form.classList.add('was-validated');  
						}, false);  
					}, false);  
				})();  
	 </script>  

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="index.php">StriveHive : Admin</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="search.php">Search</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="workout.php">Workout</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="exercise.php">Exercise</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="muscle.php">Muscle</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="category.php">Category</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="level.php">Level</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="equipment.php">Equipment</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="measurement.php">Measurement</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <header class="bg-primary text-white">
    <div class="container text-center"></div>
  </header>

  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 mx-auto">
		<h2>Workout - Display</h2>
        <form action="<?php echo ($_SERVER["PHP_SELF"])?>" method="POST" id="needs-validation" novalidate> 
          
        
		<div class="row">  
			<div class="col-sm-6 col-md-6 col-xs-12">  
				<div class="form-group">  
					<label for="workout">Workout</label>  
					<input type="text" name="workout_name" class="form-control" aria-describedby="inputGroupPrepend" value="<?php echo clean_output($workout_name) ?>" />  
					<div class="invalid-feedback">  
						Please enter a valid workout description.  
					</div>  
				</div>  
			</div>  
		</div>  

		<div class="row">  
			<div class="col-sm-12 col-md-12 col-xs-12">  
				<div class="form-group">  
					<table class="table">
					  <thead>
						<tr>
							<th scope="col">Exercise</th>
							<th scope="col"><a href='workout-detail-exercise-add.php?ID=<?php echo $workout_id?>'>&plus;</a></th>
							<th scope="col">Rep</th>
							<th scope="col">Set</th>
							<th scope="col">Weight (kg)</th>
							<th scope="col">Time (hh:mm)</th>
							<th scope="col">Workout</th>
							<th scope="col"><a href='workout-detail-workout-add.php?ID=<?php echo $workout_id?>'>&plus;</a></th>
													  
						</tr>
					  </thead>
					  <tbody>
						<?php echo $page ?>
					  </tbody>
					</table> 




				</div>  
			</div>  
		</div>  

			

		<div class="row">  
			<div class="col-sm-8 col-md-8 col-xs-12">  
				<div class="float-right">  
					 <button class="btn btn-primary rounded-0" type="submit" name='submit' id="submit">Back</button>  
				</div>                            
			</div>  
		</div>  
        </form>  


        </div>
      </div>
    </div>
  </section>


  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; StriveHive 2021</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="../js/scrolling-nav.js"></script>

</body>

</html>
