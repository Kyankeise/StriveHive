<?php

		include("../include/my_vars.php");
		include("../include/my_db.php");
		include("../include/my_functions.php");


// retrieve page id
// ----------------
		$workout_id = $_GET['ID'];
		$workout_exercise_id  = $_GET['ID1'];


// delete page
// -----------
		if ( $workout_exercise_id ) {

			$query = sprintf("DELETE FROM workout_exercise WHERE workout_exercise_id=%s ", clean_input( $workout_exercise_id ) );
			$result = $db->query($query);

			$location = "workout-detail.php?ID=" .$workout_id ;
			header ( "Location: $location " );                     
			exit;

		}
		else {

			displayError ("Input error. An error had occured while processing your submission. Please retry later.");
			exit;

		}
