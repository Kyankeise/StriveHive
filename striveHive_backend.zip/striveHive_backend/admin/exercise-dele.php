<?php

		include("../include/my_vars.php");
		include("../include/my_db.php");
		include("../include/my_functions.php");


// retrieve page id
// ----------------
		$id = $_GET['ID'];


// delete page
// -----------
		if ($id) {

			$query = sprintf("DELETE FROM exercise_muscle WHERE exercise_muscle_exercise_id=%s ", clean_input( $id ) );
			$result = $db->query($query);
			
			$query = sprintf("DELETE FROM exercise_category WHERE exercise_category_exercise_id=%s ", clean_input( $id ) );
			$result = $db->query($query);

			$query = sprintf("DELETE FROM exercise_level WHERE exercise_level_exercise_id=%s ", clean_input( $id ) );
			$result = $db->query($query);

			$query = sprintf("DELETE FROM exercise_equipment WHERE exercise_equipment_exercise_id=%s ", clean_input( $id ) );
			$result = $db->query($query);
			
			$query = sprintf("DELETE FROM exercise WHERE exercise_id=%s ", clean_input( $id ) );
			$result = $db->query($query);

 			header( "Location: exercise.php" );
 			exit;

		}
		else {

			displayError ("Input error. An error had occured while processing your submission. Please retry later.");
			exit;

		}
