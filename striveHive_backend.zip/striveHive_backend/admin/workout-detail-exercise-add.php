<?php

    // parse includes
    // --------------
 			include("../include/my_vars.php");
			include("../include/my_db.php");
			include("../include/my_functions.php");


    // process, if user pressed 'submit'
    //----------------------------------
        if ( isset($_POST['submit']) ) {
 
            // retrieve details from input
            //----------------------------------
                $workout_id		= filter_var($_POST['ID'], FILTER_SANITIZE_STRING) ;
                
				$exercise		= filter_var_array($_POST['exercise'], FILTER_SANITIZE_STRING);
 				$rep			= filter_var_array($_POST['rep'], FILTER_SANITIZE_STRING);
				$set			= filter_var_array($_POST['set'], FILTER_SANITIZE_STRING);
 				$weight			= filter_var_array($_POST['weight'], FILTER_SANITIZE_STRING);
 				$time			= filter_var_array($_POST['time'], FILTER_SANITIZE_STRING);

 
			// validate for duplicate workout
			// ------------------------------
				$workout_name = trim($workout_id);
				
				if( empty($workout_id) ) {
					$errmsg .= 'A serious error has occured. Cannot proceed <br />'	;			
				} else {

					$query = sprintf("SELECT * FROM workout WHERE workout_id=%s LIMIT 1", clean_input( $workout_id ) );				
					$result = $db->query($query);
					if ( count($result) == 0 ) {
						$errmsg .= 'This is a serious error. I will not proceed <br />'	;	
					}
					
				}

			// bail out if error with workout name
			// -----------------------------------	
				if ($errmsg) {
						displayError ($errmsg);
						exit;
				}



			// validate entries
			// ----------------
				$empty = TRUE;
				foreach ( $exercise as $key=>$exer) {
						if( !empty($exer) ) $empty = FALSE;
				}

				if($empty) $errmsg .= 'Please select an exercise for this workout. Amended to proceed <br />'	;	


		
			// if exercise selected, validated
			// ----------------------------------
				if( !$errmsg && $exercise) {

					foreach ( $exercise as $key=>$exer) {

						if($exer) {
							// must have at least one selection
							// --------------------------------
								if (!$rep[$key] && !$set[$key] && !$weight[$key] && !$time[$key]) {
									
									$errmsg .= 'Th exercise must contain a measurement selection. Time in the form 00:00 - 12:00 - 24:00 <br />';
									
								}
			
							// if set selected, must have reps
							// -------------------------------
								if ( ($rep[$key] && !$set[$key]) || (!$rep[$key] && $set[$key]) ) {
									
									$errmsg .= 'This exercise must contain both rep and set if measurement is used.<br />';
									
								}
						}
					
					}
					
				}
 //print_r(compact(array_keys(get_defined_vars()))); exit;

			// bail out if error message
			// -------------------------	
				if ($errmsg) {
						displayError ($errmsg);
						exit;
				}


			// for valid workout-exercise
			// --------------------------
				foreach ( $exercise as $key=>$exer) {

					if($exer) {
						
						if( $set[$key] == '') $set[$key] = 'NULL';
						if( $rep[$key] == '') $rep[$key] = 'NULL';
						if( $weight[$key] == '' ) $weight[$key] = 'NULL';
						
						
						$query = sprintf("INSERT INTO workout_exercise ( workout_exercise_workout_id, workout_exercise_exercise_id, workout_exercise_set, workout_exercise_rep, workout_exercise_weight, workout_exercise_time  ) 
								values(%s, %s, %s, %s, %s, '%s')",  $workout_id, $exer, $set[$key], $rep[$key], $weight[$key], $time[$key] ) ;
						$result = $db->query($query);
			
					}
				}
				
							
			    
			    $location = "workout-detail.php?ID=" .$workout_id ;
                header ( "Location: $location " );                     
                exit;



					
		} else {
			
				// validate input
				// --------------
					$workout_id	= filter_var($_GET['ID'], FILTER_SANITIZE_STRING) ;

					$query = sprintf("SELECT * FROM workout WHERE workout_id=%s LIMIT 1", clean_input( $workout_id ) );				
					$result = $db->query($query);

					if ( count($result) == 0 ) {
						$errmsg .= 'A workout by this ID does not exists. Amended to proceed <br />'	;	
					} else { 
						$workout_name = clean_output( $result[0]->workout_name );
					}
					

				// bail out if error message
				// -------------------------	
					if ($errmsg) {
							displayError ($errmsg);
							exit;
					}
				
				// load exercises
				// --------------
					$query  = "SELECT * FROM exercise ORDER BY exercise_name";
					$result = $db->query($query);
					$exercise_page = '';

					if ( count($result) > 0 ) {

							$exercise_page = "<option selected></option>";

							foreach( $result as $i ) {
								$exercise_page .= '<option value="' .$i->exercise_id .'">' .clean_output($i->exercise_name) .'</option>';
							}

					}
				
		
		
		}
?>
<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>StriveHive</title>

  <!-- Bootstrap core CSS -->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="../css/scrolling-nav.css" rel="stylesheet">
	<script type="text/javascript">  
				(function () {  
					'use strict';  
					window.addEventListener('load', function () {  
						var form = document.getElementById('needs-validation');  
						form.addEventListener('submit', function (event) {  
							if (form.checkValidity() === false) {  
								event.preventDefault();  
								event.stopPropagation();  
							} else {
								
							}  
							form.classList.add('was-validated');  
						}, false);  
					}, false);  
				})();  
	 </script>  

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="index.php">StriveHive : Admin</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="search.php">Search</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="workout.php">Workout</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="exercise.php">Exercise</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="muscle.php">Muscle</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="category.php">Category</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="level.php">Level</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="equipment.php">Equipment</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="measurement.php">Measurement</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <header class="bg-primary text-white">
    <div class="container text-center"></div>
  </header>

  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 mx-auto">
		<h2>Workout - Add new exercise </h2>
        <form action="<?php echo ($_SERVER["PHP_SELF"])?>" method="POST" id="needs-validation" novalidate> 
		
		<input name="ID" type="hidden" value="<?= clean_output($workout_id); ?>" >
          
        
		<div class="row">  
			<div class="col-sm-6 col-md-6 col-xs-12">  
				<div class="form-group">  
					<label for="workout">Workout</label>  
					<input type="text" name="workout_name" class="form-control" aria-describedby="inputGroupPrepend" required value="<?php echo $workout_name ?>"/>  
					<div class="invalid-feedback">  
						Please enter a valid workout description.  
					</div>  
				</div>  
			</div>  
		</div>  

		<div class="row">  

				<div class="col-lg-3 col-sm-3 col-md-3 col-xs-12">  
					<div class="form-group">  
						<label for="workout">Exercise</label>  
						  <select class="custom-select" name="exercise[]">
							<?php echo $exercise_page ?>
						  </select>
					</div>  
				</div> 

               <div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">  
                    <div class="form-group">  
                        <label for="workout">Rep</label>  
                        <input type="number" name="rep[]" class="form-control" aria-describedby="inputGroupPrepend"   />  
                        <div class="invalid-feedback">  
                            Please enter a valid workout description.  
                        </div>  
                    </div>  
                </div> 

				<div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">  
					<div class="form-group">  
						<label for="workout">Sets</label>  
						<input type="number" name="set[]" class="form-control" aria-describedby="inputGroupPrepend"   />  
						<div class="invalid-feedback">  
							Please enter a valid workout description.  
						</div>  
					</div>  
				</div> 

				<div class="col-lg-2 col-sm-2 col-md-2 col-xs-12">  
					<div class="form-group">  
						<label for="workout">Weight(kg)</label>  
						<input type="number" name="weight[]" class="form-control" aria-describedby="inputGroupPrepend"  />  
						<div class="invalid-feedback">  
							Please enter a valid workout description.  
						</div>  
					</div>  
				</div> 
                
				<div class="col-lg-2  col-sm-2 col-md-2 col-xs-12">  
					<div class="form-group">  
						<label>Time</label>  
						<input type="time" name="time[]" class="form-control" aria-describedby="inputGroupPrepend"  />  
						<div class="invalid-feedback">  
							Please enter a valid time.  
						</div>  
					</div>  
				</div> 
 
             
                 
            </div>  

			<br />

            <div class="row">  
                <div class="col-sm-6 col-md-6 col-xs-12">  
                    <div class="float-right">  
                         <button class="btn btn-primary rounded-0" type="submit" name='submit' id="submit">Submit</button>  
                    </div>                            
                </div>  
            </div>  
        </form>  


        </div>
      </div>
    </div>
  </section>


  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; StriveHive 2021</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="../js/scrolling-nav.js"></script>

</body>

</html>
