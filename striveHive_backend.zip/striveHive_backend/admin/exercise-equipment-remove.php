<?php

 			include("../include/my_vars.php");
			include("../include/my_db.php");
			include("../include/my_functions.php");


// retrieve page id
// ----------------
		$exercise = filter_var($_GET['ID1'], FILTER_SANITIZE_STRING);
		$equipment   = filter_var($_GET['ID2'], FILTER_SANITIZE_STRING);

// delete page
// -----------
		if ($exercise && $equipment) {

			$query = sprintf("DELETE FROM exercise_equipment WHERE exercise_equipment_exercise_id=%s AND exercise_equipment_equipment_id=%s ", clean_input( $exercise ), clean_input( $equipment ) );
			$result = $db->query($query);
			
			$location = 'exercise-detail.php?ID=' .$exercise ;
 			header( "Location: $location" );
 			exit;

		}
		else {

			displayError ("Input error. An error had occured while processing your submission. Please retry later.");
			exit;

}
