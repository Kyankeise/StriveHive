<?php

/*===================================================================*/
/* INPUT - Define variables used in script                           */
/*===================================================================*/


// edited by kyan on the 23/08 added wellness table

	// Global variables & settings
	// ---------------------------
				include( "../include/my_vars.php") ;


	// declare local variables
	// ------------------------
				$conn = '';						/* connection to server */
				$sql = '';						/* sql statement */
				$result = '';					/* result from server */

				
	// create table SQL statement (shortcut) 	
	// -------------------------------------			
				$create_user = $create_contact = $create_statistic = '';
				$create_hive = $create_gender = '';
				$create_action = '';		
				$create_intention = $create_motivation = $create_confidence = '';
				$create_user_hive = $create_user_action = '';
				$create_question = '';
				$create_answer = '';
				$create_question_answer = '';
				
			



	// define variables which hold SQL statements to create tables
	// -----------------------------------------------------------
				$create_user = "CREATE TABLE IF NOT EXISTS user (
								user_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								user_1st_name VARCHAR(128) NULL,
								user_2nd_name VARCHAR(128) NULL,
								user_DOB DATETIME, 
								user_gender INTEGER(11),     
								user_measurement CHAR(1),
								user_action INTEGER(11),
								user_notification VARCHAR(3),
								user_photo VARCHAR(128) NULL,
								user_last_created DATETIME,
								PRIMARY KEY(user_id)
							)" ;
							
	/*				gender = male, female, other, etc (in table)
	 * 				measurement = imperial, metric  I, M , fixed
	 * 				action = track or play etc (in table)
	 * 				
	 */
				$create_contact = "CREATE TABLE IF NOT EXISTS contact (
									contact_id INTEGER(11) NOT NULL AUTO_INCREMENT,
									contact_user_id INTEGER(11),
									contact_name VARCHAR(64),
									contact_email VARCHAR(254),
									contact_phone VARCHAR(28),
									contact_password VARCHAR(256),
									contact_last_accessed DATETIME,
									contact_hash_key VARCHAR(256) NULL,
									PRIMARY KEY(contact_id)
							)" ;


				$create_statistic = "CREATE TABLE IF NOT EXISTS statistic (
								statistic_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								statistic_user_id INTEGER(11),
								statistic_height INTEGER(8),
								statistic_weight INTEGER(8),
								statistic_date DATETIME,
								PRIMARY KEY(statistic_id)
							)" ;

                $create_question = "CREATE TABLE IF NOT EXISTS question (
                                question_id INTEGER(11) NOT NULL AUTO_INCREMENT,
                                question_name VARCHAR(254) NULL,
                                PRIMARY KEY(question_id)
                            )" ;


                $create_answer = "CREATE TABLE IF NOT EXISTS answer (
	                            answer_id INTEGER(8) NOT NULL AUTO_INCREMENT,
	                            answer_name INTEGER(8) NULL,
	                            PRIMARY KEY(answer_id)
                            )" ;


				$create_hive = "CREATE TABLE IF NOT EXISTS hive (
								hive_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								hive_name VARCHAR(128) NULL,
								hive_user_owner INTEGER(11),
								hive_create_date DATETIME,
								PRIMARY KEY(hive_id)
							)" ;

							
				$create_gender = "CREATE TABLE IF NOT EXISTS gender (
								gender_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								gender_name VARCHAR(128) NULL,
								PRIMARY KEY(gender_id)
							)" ;
					  
							
				$create_action = "CREATE TABLE IF NOT EXISTS action (
								action_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								action_name VARCHAR(128) NULL,
								PRIMARY KEY(action_id)
							)" ;


				$create_intention = "CREATE TABLE IF NOT EXISTS intention (
								intention_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								intention_user_id INTEGER(11),
								intention_name TEXT NULL,
								intention_date DATETIME,
								PRIMARY KEY(intention_id)
							)" ;
							

				$create_motivation = "CREATE TABLE IF NOT EXISTS motivation (
								motivation_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								motivation_user_id INTEGER(11),
								motivation_name TEXT NULL,
								motivation_date DATETIME,
								PRIMARY KEY(motivation_id)
							)" ;
							
							
				$create_confidence = "CREATE TABLE IF NOT EXISTS confidence (
								confidence_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								confidence_user_id INTEGER(11),
								confidence_name TEXT NULL,
								confidence_date DATETIME,
								PRIMARY KEY(confidence_id)
							)" ;


// ---------------------------------------------------------------------------
							
				$create_user_hive =	"CREATE TABLE IF NOT EXISTS user_hive (
								user_hive_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								user_hive_user_id INTEGER(11),
								user_hive_hive_id INTEGER(11) ,
								user_hive_join_date DATETIME,
								PRIMARY KEY(user_hive_id)
							)" ;

							
				$create_user_action = " CREATE TABLE IF NOT EXISTS user_action (
								user_action_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								user_action_user_id INTEGER(11),
								user_action_action_id INTEGER(11),
								user_action_date DATETIME,
								PRIMARY KEY(user_action_id)
							)" ;

                $create_question_answer = " CREATE TABLE IF NOT EXISTS  question_answer (
	                            question_answer_id INTEGER(11) NOT NULL AUTO_INCREMENT,
	                            question_answer_question_id INTEGER(11),
	                            question_answer_answer_id INTEGER(11),
	                            PRIMARY KEY(question_answer_id)
							)" ; 

				
/*===================================================================*/
/* PROCESS & OUTPUT                                                          */
/*===================================================================*/


	// connect to mySQL server using contact values, display error if failed
	// ---------------------------------------------------------------------
				$conn = mysqli_connect( DB_SERVER, DB_USER, DB_PASS );
				if (mysqli_connect_error()) {
					echo "Failed to connect to MySQL: " . mysqli_connect_error();
				}


	// select database
	// ---------------
				mysqli_select_db( $conn, DB_DATABASE );


	// create tables using the defination above
	// ----------------------------------------

				$result = mysqli_query($conn, $create_user) or die( mysqli_error($conn) );
				$result = mysqli_query($conn, $create_question) or die(mysqli_error($conn) );
				$result = mysqli_query($conn, $create_answer) or die(mysqli_error($conn) );
				$result = mysqli_query($conn, $create_question_answer) or die(mysqli_error($conn) );
				$result = mysqli_query($conn, $create_contact) or die(mysqli_error($conn) );
				$result = mysqli_query($conn, $create_statistic) or die(mysqli_error($conn) );
				$result = mysqli_query($conn, $create_hive) or die( mysqli_error($conn) );
				$result = mysqli_query($conn, $create_gender) or die(mysqli_error($conn) );
				$result = mysqli_query($conn, $create_action)  or die(mysqli_error($conn) );

				$result = mysqli_query($conn, $create_intention) or die(mysqli_error($conn) );
				$result = mysqli_query($conn, $create_motivation) or die(mysqli_error($conn) );
				$result = mysqli_query($conn, $create_confidence) or die( mysqli_error($conn) );
				$result = mysqli_query($conn, $create_user_hive) or die(mysqli_error($conn) );
				$result = mysqli_query($conn, $create_user_action) or die(mysqli_error($conn) );


			
	


	// close connection
	// ----------------
				mysqli_close($conn);




	// inform user & terminate
	// -----------------------
				echo ("Update of database [ " . DB_DATABASE ." ] , profile module is now completed.");


		
?>
