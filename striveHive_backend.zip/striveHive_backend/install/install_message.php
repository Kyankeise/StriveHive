<?php

/*===================================================================*/
/* INPUT - Define variables used in script                           */
/*===================================================================*/


	// Global variables & settings
	// ---------------------------
				include( "../include/my_vars.php") ;


	// declare local variables
	// ------------------------
				$conn = '';						/* connection to server */
				$sql = '';						/* sql statement */
				$result = '';					/* result from server */

				
	// create table SQL statement (shortcut) 	
	// -------------------------------------			
				$create_hive = $create_hive_user = '';
				$create_msg_user =  $create_msg_hive ='';


	// define variables which hold SQL statements to create tables
	// -----------------------------------------------------------
				// hive
				$create_hive = " CREATE TABLE IF NOT EXISTS hive (
								hive_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								hive_user_id INTEGER(11), 
								hive_title VARCHAR(128),
								hive_create_date DATETIME, 
								hive_status CHAR(1),     
								PRIMARY KEY(hive_id)
							)" ;

				// user hive
				$create_hive_user = " CREATE TABLE IF NOT EXISTS hive_user (
								hive_user_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								hive_user_hive_id INTEGER(11),
								hive_user_user_id INTEGER(11),
								hive_user_create_date DATETIME, 
								hive_user_status CHAR(1),     
								PRIMARY KEY(hive_user_id)
							)" ;

				// user messages
				$create_msg_user = "CREATE TABLE IF NOT EXISTS msg_user (
								msg_user_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								msg_user_user_id INTEGER(11),
								msg_user_msg TEXT NULL,
								msg_user_date DATETIME, 
								msg_user_sent DATETIME, 
								msg_user_status CHAR(1),     
								PRIMARY KEY(msg_user_id)
							)" ;


				// hive messages
				$create_msg_hive = "CREATE TABLE IF NOT EXISTS msg_hive (
								msg_hive_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								msg_hive_hive_id INTEGER(11),
								msg_hive_user_id INTEGER(11),
								msg_hive_msg TEXT NULL,
								msg_hive_date DATETIME, 
								msg_hive_sent DATETIME, 
								msg_hive_status CHAR(1),     
								PRIMARY KEY(msg_hive_id)
							)" ;
				
/*===================================================================*/
/* PROCESS & OUTPUT                                                          */
/*===================================================================*/


	// connect to mySQL server using contact values, display error if failed
	// ---------------------------------------------------------------------
				$conn = mysqli_connect( DB_SERVER, DB_USER, DB_PASS );
				if (mysqli_connect_error()) {
					echo "Failed to connect to MySQL: " . mysqli_connect_error();
				}


	// select database
	// ---------------
				mysqli_select_db( $conn, DB_DATABASE );


	// remove tables if exists
	// -----------------------
				$sql = "DROP TABLE IF EXISTS hive, hive_user, msg_user, msg_hive" ;
				$result = mysqli_query($conn, $sql) or die( mysqli_error($conn) );


	// create tables using the defination above
	// ----------------------------------------
				$result = mysqli_query($conn, $create_hive ) or die( mysqli_error($conn) );
				$result = mysqli_query($conn, $create_hive_user ) or die( mysqli_error($conn) );
				$result = mysqli_query($conn, $create_msg_user ) or die( mysqli_error($conn) );
				$result = mysqli_query($conn, $create_msg_hive) or die(mysqli_error($conn) );


	// close connection
	// ----------------
				mysqli_close($conn);


	// inform user & terminate
	// -----------------------
				echo ("Update of database [ " . DB_DATABASE ." ] with message files is now completed.");

		
?>
