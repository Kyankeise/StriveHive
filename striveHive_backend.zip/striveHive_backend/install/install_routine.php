<?php

/*===================================================================*/
/* INPUT - Define variables used in script                           */
/*===================================================================*/


	// Global variables & settings
	// ---------------------------
				include( "../include/my_vars.php") ;


	// declare local variables
	// ------------------------
				$conn = '';						/* connection to server */
				$sql = '';						/* sql statement */
				$result = '';					/* result from server */

				
	// create table SQL statement (shortcut) 	
	// -------------------------------------			
				$create_routine = $create_routine_exercise = '';
				

	// define variables which hold SQL statements to create tables
	// -----------------------------------------------------------
				$create_routine = "CREATE TABLE IF NOT EXISTS routine (
								routine_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								routine_name VARCHAR(128) NULL,
								routine_user_id INTEGER(11),
								routine_last_created DATETIME,
								PRIMARY KEY(routine_id)
							)" ;

							
				$create_routine_exercise = "CREATE TABLE IF NOT EXISTS routine_exercise (
								routine_exercise_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								routine_exercise_routine_id INTEGER(11),
								routine_exercise_exercise_id INTEGER(11),
								routine_exercise_set INTEGER(4),
								routine_exercise_rep INTEGER(4),
								routine_exercise_weight INTEGER(4),
								routine_exercise_routine_child_id INTEGER(11),
								routine_exercise_time VARCHAR(8) NULL,
								PRIMARY KEY(routine_exercise_id)
							)" ;

				
/*===================================================================*/
/* PROCESS & OUTPUT                                                          */
/*===================================================================*/


	// connect to mySQL server using contact values, display error if failed
	// ---------------------------------------------------------------------
				$conn = mysqli_connect( DB_SERVER, DB_USER, DB_PASS );
				if (mysqli_connect_error()) {
					echo "Failed to connect to MySQL: " . mysqli_connect_error();
				}


	// select database
	// ---------------
				mysqli_select_db( $conn, DB_DATABASE );


	// create tables using the defination above
	// ----------------------------------------
				$result = mysqli_query($conn, $create_routine ) or die( mysqli_error($conn) );
				$result = mysqli_query($conn, $create_routine_exercise) or die(mysqli_error($conn) );


	// close connection
	// ----------------
				mysqli_close($conn);


	// inform user & terminate
	// -----------------------
				echo ("Update of database [ " . DB_DATABASE ." ], routines, is now completed.");

		
?>
