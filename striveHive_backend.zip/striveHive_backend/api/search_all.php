<?php

// Description:
//       api to send all search results based on muscle, category, level, equipment
//
// Comments:
// 		to call use www.strivehive.app/api/search.php?muscle=4&category=&level=&equipment=
// 		there is 4 input parameter and a minimum  of 1 is required. Client id will added when flutter app are functioning
// 		errors, if found,  must be send to client to be investigated
// 
// test, run in browser:
// 	http://localhost/striveHive_api_examples/api/search.php?muscle=4&category=&level=&equipment=
//	http://localhost/striveHive_api_examples/api/search.php?muscle=4&category=2&level=&equipment=
//	http://localhost/striveHive_api_examples/api/search.php?muscle=&category=&level=&equipment= [error]
//	http://localhost/striveHive_api_examples/api/search.php?muscle=44444&category=&level=&equipment= [stress test]
//
// ===============================================================================================================


	// include global variables and stuff
	// ----------------------------------
 			include("../include/my_vars.php");
			include("../include/my_db.php");
			include("../include/my_functions.php");
			include("../include/ex_files.php") ;


	// declare variables
	// -----------------
			$arr = array();
			$muscle = $category = $level = $equipment = '';
			$where = $select = $from = $join = '';
			$first = FALSE;


	// clean, trim and retrieve inputs  
	// -------------------------------
			$muscle   	= trim( filter_var($_GET['muscle'], FILTER_SANITIZE_STRING) );
			$category  	= trim( filter_var($_GET['category'], FILTER_SANITIZE_STRING) );
			$level  	= trim( filter_var($_GET['level'], FILTER_SANITIZE_STRING) );
			$equipment 	= trim( filter_var($_GET['equipment'], FILTER_SANITIZE_STRING) );


	// validate - minimum of 1 entry is required to proceed
	// ----------------------------------------------------
		if ( empty($muscle) && empty($category) && empty($level) && empty($equipment) ) {
			
				$arr['Error']=array();
				array_push( $arr['Error'] , 'Error - At least 1 selection is required to proceed.' );
			
		} else {

		
	// process - create the query statement according to the inputs submitted
	// ----------------------------------------------------------------------

		// set up sql variables
		// --------------------
			$where = 'WHERE ';
			$select = 'SELECT * ';
			$from = 'FROM exercise ';
			$join = '';
			$first = FALSE;

		// if exercise by muscle is required
		// --------------------------------- 
			if($muscle) {
				$where .= 'exercise_muscle.exercise_muscle_muscle_id=' .$muscle .' ';
				$join  .= 'INNER JOIN exercise_muscle ON exercise.exercise_id=exercise_muscle.exercise_muscle_exercise_id ';
				$first = TRUE;
			}

		// if exercise by category is required
		// ----------------------------------- 
			if($category) {
				if($first) $where .= 'AND ';
				$where .= 'exercise_category.exercise_category_category_id=' .$category .' ';
				$join  .= 'INNER JOIN exercise_category ON exercise.exercise_id=exercise_category.exercise_category_exercise_id ';
				$first = TRUE;
			}
		
		// if exercise by level is required
		// -------------------------------- 
			if($level) {
				if($first) $where .= 'AND ';
				$where .= 'exercise_level.exercise_level_level_id=' .$level .' ';
				$join  .= 'INNER JOIN exercise_level ON exercise.exercise_id=exercise_level.exercise_level_exercise_id ';	
				$first = TRUE;
			}

		// if exercise by equipment is required
		// ------------------------------------ 
			if($equipment) {
				if($first) $where .= 'AND ';
				$where .= 'exercise_equipment.exercise_equipment_equipment_id=' .$equipment .' ';
				$join  .= 'INNER JOIN exercise_equipment ON exercise.exercise_id=exercise_equipment.exercise_equipment_exercise_id ';
				$first = TRUE;
			}


		// set up the query and retrieve the rows, if any
		// ---------------------------------------------- 
			$query = $select .$from .$join .$where;
			$result = $db->query($query);


		// create output array
		// ------------------- 
			if ( count($result) > 0 ) {

					// define the array structure
					// --------------------------
						$arr["SearchBy"]=array();
						$arr["Exercise"]=array();

						array_push( $arr["SearchBy"] , 'muscle=' .$muscle .', ' .'category=' .$category .', ' .'level=' .$level .', ' .'equipment=' .$equipment ) ;

						foreach( $result as $i ) {
								array_push( $arr["Exercise"],  getExerciseDet($i->exercise_id) );
						}


			} else { 
						$arr['Error']=array();
						array_push($arr['Error'] , 'Error - No records found for this search.' );
			}


		} 



// output json string for client to retrive. Use browser to test
// -------------------------------------------------------------
		header('Content-type: application/json');
		echo (json_encode($arr, JSON_PRETTY_PRINT) );

?>
