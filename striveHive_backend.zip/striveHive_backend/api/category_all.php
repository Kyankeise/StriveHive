<?php 

// include global variables
// ------------------------
        include( "../include/my_vars.php") ;
        include( "../include/my_db.php") ;
        include( "../include/my_functions.php") ;
        include( "../include/ex_files.php") ;        

// local variables
// ---------------       
        $query = '';
        $result = '';
		$man = '';

// select the all records from category table
// ------------------------------------------
		$query = sprintf("SELECT * FROM category ");
		$result = $db->query($query);
								 
// generate JSON 
// ------------- 
		if ( count($result) > 0 ) {

			// define the array structure
			// --------------------------
			$arr['Category']=array();

			foreach( $result as $i ) {

				array_push($arr['Category'] , getCategoryDet( $i->category_id ) );


			}

		}


print_r(compact(array_keys(get_defined_vars()))); exit;

// output json string
// ------------------
		header('Content-type: application/json');
		echo (json_encode($arr, JSON_PRETTY_PRINT) );

?>
