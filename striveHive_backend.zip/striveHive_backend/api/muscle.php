<?php 

// Description:
//       api to send all exercises related to a muscle, to the client
//
// Comments:
// 		to call use www.strivehive.app/muscle.php?muscle='23'
// 		there is 1 input parameter. Client id will added when flutter app are functioning
// 		errors, if found,  must be send to client to be investigated
// 
//		Some of the logic might not make sense early on, but the light bulb moments will appear later
// ==================================================================================================


// More comments:
// include global variables (this is standard aand must be included in any api that users database)
// my_vars.php - global values reside here
// my_db.php - database api
// my_functions - stuff to make life easy
// ex_files - this is the SH secret hot source, contains all the base funtions
// ------------------------------------------------------------------------------------------------

// include global variables
// ------------------------
        include( "../include/my_vars.php") ;
        include( "../include/my_db.php") ;
        include( "../include/my_functions.php") ;
        include( "../include/ex_files.php") ;
        
        
// clean the input in situ
// -----------------------       
        if ($_GET['muscle'] != "") {
            $_GET['muscle'] = filter_var($_GET['muscle'], FILTER_SANITIZE_STRING);
        }


// ok, now retrieve input
// ---------------------- 	
		$muscle = $_GET['muscle'];
		
		
// declare local variables
// -----------------------       
        $query = '' ;
        $result = '';
        $arr = array();
 
		
		
// Process valid muscle. if error with input, inform user via json
// ---------------------------------------------------------------
		if( $muscle )  {
			
 
		// select the all exercises for this muscle  
		// ----------------------------------------
				$query = sprintf("SELECT * FROM muscle WHERE muscle_id=%s LIMIT 1", clean_input( $muscle ) );				
				$result = $db->query($query);


				if ( count($result) > 0 ) {

					// define the array structure
					// --------------------------
					$arr["SearchBy"]=array();
					$arr["Exercise"]=array();


					// fill in the details
					// -------------------
					$arr["SearchBy"] = getMuscleDet( $muscle );

					foreach( $result as $i ) {
							
							$arr["Exercise"] = getMuscleExercise( $i->muscle_id );

					}

				}

		} 
		
// otherwise inform user of error. This should never happen but just in case.. practise safe programming
// -----------------------------------------------------------------------------------------------------		
		else {
				$arr['Error']=array();
				array_push($arr['Error'] , 'Error - No muscle or exercles found for this search.' );
				
		}
		
		

// output json string for client to retrive. Use browser to test
// -------------------------------------------------------------
		header('Content-type: application/json');
		echo (json_encode($arr, JSON_PRETTY_PRINT) );

?>
