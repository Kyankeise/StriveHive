<?php 

// include global variables
// ------------------------
        include( "../include/my_vars.php") ;
        include( "../include/my_db.php") ;
        include( "../include/my_functions.php") ;
        include( "../include/ex_files.php") ;
        
        
// get the input and clean
// --------------------       
        if ($_GET['exercise'] != "") {
            $_GET['exercise'] = filter_var($_GET['exercise'], FILTER_SANITIZE_STRING);
        }


// retrieve input
// -------------- 	
		$exercise = $_GET['exercise'];
		
		
// local variables
// ---------------       
        $query = '' ;
        $result = '';
        $arr = array();
        $cnt = 0;

		
		
// if error input, inform user via json
// ------------------------------------
		if( $exercise )  {
			
 
		// select the all records from exercise table
		// ------------------------------------------
				$query = sprintf("SELECT * FROM exercise WHERE exercise_id=%s LIMIT 1", clean_input( $exercise ) );				
				$result = $db->query($query);


				if ( count($result) > 0 ) {

					// define the array structure
					// --------------------------
					$arr["SearchBy"]=array();
					$arr["Muscle"]=array();
					$arr["Category"]=array();
					$arr["Level"]=array();
					$arr["Equipment"]=array();
					$arr["Measurement"]=array();


					// fill in the details
					// -------------------
					$arr["SearchBy"] = getExercise( $exercise );

					foreach( $result as $i ) {
							
							$arr["Muscle"]   = getMuscle( $i->exercise_id );
							$arr["Category"] = getCategory( $i->exercise_id );
							$arr["Level"] = getLevel( $i->exercise_id );
							$arr["Equipment"] = getEquipment( $i->exercise_id );
							$arr["Measurement"] = getMeasurement( $i->exercise_id );

					}

				}

		}


// output json string
// ------------------
		header('Content-type: application/json');
		echo (json_encode($arr, JSON_PRETTY_PRINT) );



?>
