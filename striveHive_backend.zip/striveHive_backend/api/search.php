<?php 

// include global variables
// ------------------------
        include( "../include/my_vars.php") ;
        include( "../include/my_db.php") ;
        include( "../include/my_functions.php") ;
        include( "files.php") ;
        
        
// get the input, clean
// --------------------       
        if ($_GET['level'] != "") {
            $_GET['level'] = filter_var($_GET['level'], FILTER_SANITIZE_STRING);
        }
		
		if ($_GET['muscle'] != "") {
            $_GET['muscle'] = filter_var($_GET['muscle'], FILTER_SANITIZE_STRING);
		}

// retrieve input
// -------------- 	
		$level = $_GET['level'] ;
		$muscle   = $_GET['muscle'] ;
		
// local variables
// ---------------       
        $query = '' ;
        $result = '';

        $cnt = 0;
$method = $_SERVER['REQUEST_METHOD'];
$path_info 		= $_SERVER['PATH_INFO'];


$request = explode('/', trim($_SERVER['PATH_INFO'], '/'));

		  
print_r(compact(array_keys(get_defined_vars()))); exit;
		
		
// if error input, inform user via json
// ------------------------------------
		if( $level )  {
			
/* 
 select first_name, last_name, order_date, order_amount
from customers c
inner join orders o
on c.customer_id = o.customer_id

								exercise_level_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								exercise_level_exercise_id INTEGER(11),
								exercise_level_level_id INTEGER(11) ,
								exercise_muscle_id INTEGER(11) NOT NULL AUTO_INCREMENT,
								exercise_muscle_exercise_id INTEGER(11),
								exercise_muscle_muscle_id INTEGER(11) ,

 */
		// select the all records from exercise table
		// ------------------------------------------
				$query = sprintf("SELECT exercise_level_exercise_id FROM exercise_level INNER JOIN exercise_muscle ON exercise_level.exercise_level_exercise_id = exercise_muscle.exercise_muscle_exercise_id WHERE exercise_level.exercise_level_level_id=%s AND exercise_muscle.exercise_muscle_muscle_id=%s", clean_input( $level ) , clean_input( $muscle ) );				
				$result = $db->query($query);


				$arr = array();
				$arr["level"]=array();
				$arr["muscle"  ]=array();
				$arr["Exercise"  ]=array();

				if ( count($result) > 0 ) {
					
					array_push($arr["level"], getlevelDet( $level ));
					array_push($arr["muscle"], getmuscleDet( $muscle ));

					foreach( $result as $i ) {

						array_push($arr["Exercise"], getExercise( $i->exercise_level_exercise_id ));

					}

				}

}


// output json string
// ------------------
		header('Content-type: application/json');
		echo (json_encode($arr, JSON_PRETTY_PRINT) );



?>
