<?php 

// include global variables
// ------------------------
        include( "../include/my_vars.php") ;
        include( "../include/my_db.php") ;
        include( "../include/my_functions.php") ;
        include( "../include/ex_files.php") ;        

        
// get the input and clean
// --------------------       
        if ($_GET['category'] != "") {
            $_GET['category'] = filter_var($_GET['category'], FILTER_SANITIZE_STRING);
        }


// retrieve input
// -------------- 	
		$category = $_GET['category'];


// local variables
// ---------------       
        $query = '';
        $result = '';
 
// if error input, inform user via json
// ------------------------------------
		if( $category )  {
			
 
		// select the all records from exercise table
		// ------------------------------------------
				$query = sprintf("SELECT * FROM category WHERE category_id=%s LIMIT 1", clean_input( $category ) );				
				$result = $db->query($query);


				if ( count($result) > 0 ) {

					// define the array structure
					// --------------------------
					$arr["SearchBy"]=array();


					// fill in the details
					// -------------------
					$arr["SearchBy"] = getCategoryDet( $category );

					foreach( $result as $i ) {
							
							$arr["Exercise"] = getCategoryExercise( $i->category_id );

					}

				}

		}
  
 

// output json string
// ------------------
		header('Content-type: application/json');
		echo (json_encode($arr, JSON_PRETTY_PRINT) );

?>
