<?php 

// include global variables
// ------------------------
        include( "../include/my_vars.php") ;
        include( "../include/my_db.php") ;
        include( "../include/my_functions.php") ;
        include( "../include/ex_files.php") ;        

// local variables
// ---------------       
        $query = '';
        $result = '';
 

// select the all records from exercise table
// ------------------------------------------
		$query = sprintf("SELECT * FROM equipment ");
		$result = $db->query($query);
								 
// generate JSON 
// ------------- 
		if ( count($result) > 0 ) {

			// define the array structure
			// --------------------------
			$arr['Equipment']=array();

			foreach( $result as $i ) {

				array_push($arr['Equipment'] , getEquipmentDet( $i->equipment_id ) );


			}

		}

// output json string
// ------------------
		header('Content-type: application/json');
		echo (json_encode($arr, JSON_PRETTY_PRINT) );

?>
