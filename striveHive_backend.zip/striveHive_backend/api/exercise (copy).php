<?php 

// include global variables
// ------------------------
        include( "../include/my_vars.php") ;
        include( "../include/my_db.php") ;
        include( "../include/my_functions.php") ;
        include( "files.php") ;
        
        
// get the input, clean
// --------------------       
        if ($_GET['exercise'] != "") {
            $_GET['exercise'] = filter_var($_GET['exercise'], FILTER_SANITIZE_STRING);
        }


// retrieve input
// -------------- 	
		$exercise = $_GET['exercise'];
		
		
// local variables
// ---------------       
        $query = '' ;
        $result = '';
        $arr = [];
        $cnt = 0;
		$work = [];

// if error input, inform user via json
// ------------------------------------
		if( $exercise )  {
			
 
		// select the all records from exercise table
		// ------------------------------------------
				$query = sprintf("SELECT * FROM exercise WHERE exercise_id=%s LIMIT 1", clean_input( $exercise ) );				
				$result = $db->query($query);
				if ( count($result) > 0 ) {

					foreach( $result as $i ) {
						$jsonArrayObject = (array('exercise_id' => clean_output($i->exercise_id),
												  'exercise_name' => clean_output($i->exercise_name)
//												  'muscle_name'=> clean_output($muscle_name),
//												  'category_name' => clean_output($category_name),
//												  'level_name'=> clean_output($level_name),
//												  'equipment_name'=> clean_output($equipment_name),
//												  'measurement_name'=> clean_output($measurement_name),)
 												 ) );
//						$arr[$cnt] = $jsonArrayObject;
//						$cnt++;
					}

				}






			 
		// select all muscle for this exercise
		// -------------------------------------		
				$query = sprintf("SELECT * FROM exercise_muscle WHERE exercise_muscle_exercise_id=%s ", clean_input( $exercise ) );				
				$result = $db->query($query);
				if ( count($result) > 0 ) {

					foreach( $result as $i ) {

						if($result[0]->exercise_muscle_muscle_id) {
							$muscle_name = getmuscleName( $i->exercise_muscle_muscle_id ) ;
					
						
	//						$jsonArrayObject = (array('muscle_id' => clean_output($i->exercise_muscle_muscle_id),
	//												  'muscle_name' => clean_output($muscle_name),
	//												  'muscle_name'=> clean_output($muscle_name),
	//												  'category_name' => clean_output($category_name),
	//												  'level_name'=> clean_output($level_name),
	//												  'equipment_name'=> clean_output($equipment_name),
	//												  'measurement_name'=> clean_output($measurement_name),)
	//												  ));
	//						$arr[$cnt] = $jsonArrayObject;
	//						$cnt++;
						}
					}
				}




print_r(compact(array_keys(get_defined_vars()))); exit;


		// select all exercise_category
		// ---------------------------------
				$query = sprintf("SELECT * FROM exercise_category WHERE exercise_category_exercise_id=%s ", clean_input( $exercise ) );				
				$exercise_category = $db->query($query);

				
		// select all exercise_level
		// ------------------------------
				$query = sprintf("SELECT * FROM exercise_level WHERE exercise_level_exercise_id=%s ", clean_input( $exercise ) );				
				$exercise_level = $db->query($query);

		
		// select all exercise_equipment
		// -----------------------------
				$query = sprintf("SELECT * FROM exercise_equipment WHERE exercise_equipment_exercise_id=%s ", clean_input( $exercise ) );				
				$exercise_equipment = $db->query($query);


		// select all exercise_measurement
		// ------------------------------------
				$query = sprintf("SELECT * FROM exercise_measurement WHERE exercise_measurement_exercise_id=%s ", clean_input( $exercise ) );				
				$exercise_measurement = $db->query($query);

print_r(compact(array_keys(get_defined_vars()))); exit;

		
/*


				$query = sprintf("SELECT DISTINCT exercise.exercise_id, exercise.exercise_name, exercise_muscle.exercise_muscle_muscle_id, exercise_category.exercise_category_category_id, exercise_level.exercise_level_exercise_id, exercise_equipment.exercise_equipment_exercise_id, exercise_measurement.exercise_measurement_exercise_id FROM exercise INNER JOIN exercise_muscle ON exercise.exercise_id = exercise_muscle.exercise_muscle_exercise_id 
														 INNER JOIN exercise_category ON exercise.exercise_id = exercise_category.exercise_category_exercise_id
														 INNER JOIN exercise_level ON exercise.exercise_id = exercise_level.exercise_level_exercise_id
														 INNER JOIN exercise_equipment ON exercise.exercise_id = exercise_equipment.exercise_equipment_exercise_id
														 INNER JOIN exercise_measurement ON exercise.exercise_id = exercise_measurement.exercise_measurement_exercise_id
														 WHERE exercise_id=%s LIMIT 1", clean_input( $exercise ) );				



 print_r(compact(array_keys(get_defined_vars()))); exit;

                 [exercise_id] => 5
                    [exercise_name] => air bike
                    [exercise_muscle_id] => 8
                    [exercise_muscle_exercise_id] => 5
                    [exercise_muscle_muscle_id] => 5
                    [exercise_category_id] => 5
                    [exercise_category_exercise_id] => 5
                    [exercise_category_category_id] => 3
                    [exercise_level_id] => 5
                    [exercise_level_exercise_id] => 5
                    [exercise_level_level_id] => 1
                    [exercise_equipment_id] => 5
                    [exercise_equipment_exercise_id] => 5
                    [exercise_equipment_equipment_id] => 1
                    [exercise_measurement_id] => 5
                    [exercise_measurement_exercise_id] => 5
                    [exercise_measurement_measurement_id] => 3
                )
*/
		if($result[0]->exercise_muscle_muscle_id) {
				$muscle_name = getmuscleName( $result[0]->exercise_muscle_muscle_id ) ;
		}
		
		if($result[0]->exercise_category_category_id) {	
				$category_name = getExerciseTypeName( $result[0]->exercise_category_category_id ) ;
		}

		if($result[0]->exercise_level_level_id) {
				$level_name = getlevelName( $result[0]->exercise_level_level_id) ;
		}

		if($result[0]->exercise_equipment_equipment_id) {
				$equipment_name = getEquipmentName( $result[0]->exercise_equipment_equipment_id ) ;
		}

		if($result[0]->exercise_measurement_measurement_id) {
				$measurement_name = getMeasurementTypeName( $result[0]->exercise_measurement_measurement_id ) ;
		}
						 
						 
		// generate JSON 
		// ------------- 
				if ( count($result) > 0 ) {

					foreach( $result as $i ) {
						$jsonArrayObject = (array('exercise_id' => clean_output($i->exercise_id),
												  'exercise_name' => clean_output($i->exercise_name),
												  'muscle_name'=> clean_output($muscle_name),
												  'category_name' => clean_output($category_name),
												  'level_name'=> clean_output($level_name),
												  'equipment_name'=> clean_output($equipment_name),
												  'measurement_name'=> clean_output($measurement_name),)
												  );
						$arr[$cnt] = $jsonArrayObject;
						$cnt++;
					}

				}

		}
		
//print_r(compact(array_keys(get_defined_vars()))); exit;	

// output json string
// ------------------
		header('Content-type: application/json');
		echo (json_encode($arr, JSON_PRETTY_PRINT) );

?>
