<?php 

// include global variables
// ------------------------
        include( "../include/my_vars.php") ;
        include( "../include/my_db.php") ;
        include( "../include/my_functions.php") ;
        include( "../include/ex_files.php") ;        

        
// get the input and clean
// --------------------       
        if ($_GET['level'] != "") {
            $_GET['level'] = filter_var($_GET['level'], FILTER_SANITIZE_STRING);
        }


// retrieve input
// -------------- 	
		$level = $_GET['level'];


// local variables
// ---------------       
        $query = '';
        $result = '';
 
// if error input, inform user via json
// ------------------------------------
		if( $level )  {
			
 
		// select the all records from exercise table
		// ------------------------------------------
				$query = sprintf("SELECT * FROM level WHERE level_id=%s LIMIT 1", clean_input( $level ) );				
				$result = $db->query($query);


				if ( count($result) > 0 ) {

					// define the array structure
					// --------------------------
					$arr["SearchBy"]=array();


					// fill in the details
					// -------------------
					$arr["SearchBy"] = getLevelDet( $level );

					foreach( $result as $i ) {
							
							$arr["Exercise"] = getlevelExercise( $i->level_id );

					}

				}

		}
  
 

// output json string
// ------------------
		header('Content-type: application/json');
		echo (json_encode($arr, JSON_PRETTY_PRINT) );

?>
