<?php 

// include global variables
// ------------------------
        include( "../include/my_vars.php") ;
        include( "../include/my_db.php") ;
        include( "../include/my_functions.php") ;
        include( "../include/ex_files.php") ;        

        
// get the input and clean
// --------------------       
        if ($_GET['equipment'] != "") {
            $_GET['equipment'] = filter_var($_GET['equipment'], FILTER_SANITIZE_STRING);
        }


// retrieve input
// -------------- 	
		$equipment = $_GET['equipment'];


// local variables
// ---------------       
        $query = '';
        $result = '';
 
// if error input, inform user via json
// ------------------------------------
		if( $equipment )  {
			
 
		// select the all records from exercise table
		// ------------------------------------------
				$query = sprintf("SELECT * FROM equipment WHERE equipment_id=%s LIMIT 1", clean_input( $equipment ) );				
				$result = $db->query($query);


				if ( count($result) > 0 ) {

					// define the array structure
					// --------------------------
					$arr["SearchBy"]=array();


					// fill in the details
					// -------------------
					$arr["SearchBy"] = getEquipmentDet( $equipment );

					foreach( $result as $i ) {
							
							$arr["Exercise"] = getEquipmentExercise( $i->equipment_id );

					}

				}

		}
  
 

// output json string
// ------------------
		header('Content-type: application/json');
		echo (json_encode($arr, JSON_PRETTY_PRINT) );

?>
