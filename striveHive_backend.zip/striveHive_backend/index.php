<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>StriveHive</title>

  <!-- Bootstrap core CSS -->
  <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom styles for this template -->
  <link href="../css/scrolling-nav.css" rel="stylesheet">

</head>

<body id="page-top">

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <div class="container">
      <a class="navbar-brand js-scroll-trigger" href="index.php">StriveHive : Admin</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="search.php">Search</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="exercise.php">Exercise</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="muscle.php">Muscle</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="category.php">Category</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="level.php">Level</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="equipment.php">Equipment</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="url.php">URLs</a></li>
         <li class="nav-item"><a class="nav-link js-scroll-trigger" href="description.php">Description</a></li>
        </ul>
      </div>
    </div>
  </nav>

  <header class="bg-primary text-white">
    <div class="container text-center"></div>
  </header>

  <section id="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 mx-auto">

		<h2>Welcome to admin panel - Exercise module</h2>
		<br />
		<p>Use the menu above to add/delete/amend details : -</p>
		<p>Equipment -  used for one of many exercises eg kettlebell, ropes, etc</p>
		<p>Level -  suitable for each exercises eg beginner, expert, etc</p>
		<p>Category -  categorised each exercise eg for strength, cardio etc</p>
		<p>Muscle -  muscle group that will have an impact from the exercises</p>
		<p>Exercise -  the exercises with the relationship above</p>

        </div>
      </div>
    </div>
  </section>


  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; StriveHive 2021</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="../vendor/jquery/jquery.min.js"></script>
  <script src="../vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Plugin JavaScript -->
  <script src="../vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom JavaScript for this theme -->
  <script src="../js/scrolling-nav.js"></script>

</body>

</html>
