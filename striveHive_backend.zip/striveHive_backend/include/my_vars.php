<?php

// Database Settings - amend the following: DB_USER, DB_PASS, DB_DATABASE
// ----------------------------------------------------------------------

	
		define("DB_SERVER", "localhost");
		define("DB_USER", "root");
		define("DB_PASS", "root");
		define("DB_DATABASE", "striveHive");

// Site Customization - amend the following: SITE_NAME, SITE_URL
// -------------------------------------------------------------

		define("APP_NAME", "StriveHive");
		define("SITE_NAME", "Strivehive.online");
		define("SITE_URL", "https://www.strivehive.online"); 
		define("SITE_URL", "http://localhost/");
		define("SITE_EMAIL", "support@strivehive.online");


// Security - amend the following: COOKIE_NAME, SECRET_WORD
// --------------------------------------------------------

		define("COOKIE_NAME", APP_NAME);
		define("SECRET_WORD", "cookies are yummy");
		define("COOKIE_EXPIRE", "360000");


// Templates
// ---------
		define("TMPL_ERROR", realpath(dirname(__DIR__))  ."/include/errors.html");


// Stuff - I'll leave this here and move it to table later
// -------------------------------------------------------
		define("KEY1", "VDiaAOCwmbeeE2iM0WGoZVfew/bwPDMOc3IN/FTE6eI=");
		define("KEY2", "bznsz59I6uowp+hNiuIgNYFqMrx7a6VeEnsSbQteSjYTFPqx+7g2Qf+M76gXvOdUot59GyIaTl6tL5Sg6NtElA==");

?>
